import React, { useState } from 'react';
import { 
  Package, 
  Sparkles, 
  ShoppingBag, 
  Plus, 
  Check, 
  ArrowRight, 
  DollarSign, 
  Loader2, 
  TrendingDown, 
  ShieldCheck, 
  SlidersHorizontal,
  Bot
} from 'lucide-react';
import { Product, StorePrice, ShoppingKit } from '../types';
import { INITIAL_PRODUCTS } from '../data/mockCatalog';

interface KitBuilderProps {
  onAddToCart: (product: Product, store: StorePrice) => void;
  onAddMultipleToCart: (items: { product: Product; store: StorePrice }[]) => void;
  onSelectProduct: (product: Product) => void;
}

export const KitBuilder: React.FC<KitBuilderProps> = ({
  onAddToCart,
  onAddMultipleToCart,
  onSelectProduct,
}) => {
  const [selectedTheme, setSelectedTheme] = useState('Remote Work & Productivity Suite');
  const [customTheme, setCustomTheme] = useState('');
  const [targetBudget, setTargetBudget] = useState(700);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeKit, setActiveKit] = useState<ShoppingKit | null>(null);

  // Pre-configured starter kits
  const PRESET_KITS: ShoppingKit[] = [
    {
      id: 'kit-wfh-desk',
      title: 'Ultimate Minimalist WFH & Productivity Setup',
      description: 'Engineered for all-day focus, ergonomic comfort, and premium multi-device workflow without cable clutter.',
      targetBudget: 750,
      totalPrice: 512.98,
      savingsTotal: 126.01,
      items: [
        {
          categoryName: 'Productivity Audio',
          selectedProduct: INITIAL_PRODUCTS[0], // Sony XM5
        },
        {
          categoryName: 'Ergonomic Input Control',
          selectedProduct: INITIAL_PRODUCTS[2], // MX Master 3S
        },
        {
          categoryName: 'Rapid Charging Station',
          selectedProduct: INITIAL_PRODUCTS[7], // Anker 737
        }
      ]
    },
    {
      id: 'kit-travel-audio',
      title: 'Digital Nomad & Commuter Travel Kit',
      description: 'Compact, TSA-approved powerhouse kit for frequent flyers, remote creators, and cafe workers.',
      targetBudget: 600,
      totalPrice: 427.99,
      savingsTotal: 121.99,
      items: [
        {
          categoryName: 'ANC Headset',
          selectedProduct: INITIAL_PRODUCTS[0],
        },
        {
          categoryName: 'Fast PD Power',
          selectedProduct: INITIAL_PRODUCTS[7],
        }
      ]
    },
    {
      id: 'kit-gourmet-cafe',
      title: 'Artisan Home Espresso & Morning Routine',
      description: 'Transform your kitchen into a third-wave cafe with fresh bean-to-cup extraction.',
      targetBudget: 800,
      totalPrice: 559.95,
      savingsTotal: 140.00,
      items: [
        {
          categoryName: 'Espresso Hub',
          selectedProduct: INITIAL_PRODUCTS[4], // Breville Barista Express
        }
      ]
    }
  ];

  const currentDisplayKit = activeKit || PRESET_KITS[0];

  const handleGenerateCustomKit = async (e: React.FormEvent) => {
    e.preventDefault();
    const promptTheme = customTheme.trim() || selectedTheme;
    if (!promptTheme) return;

    setIsGenerating(true);

    try {
      const res = await fetch('/api/agent/build-kit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kitTheme: promptTheme,
          targetBudget,
          specificNeeds: 'Focus on high durability, verified customer satisfaction, and optimal price savings.',
        }),
      });

      if (!res.ok) throw new Error('Kit generation failed');
      const data = await res.json();

      // Transform backend kit into UI ShoppingKit
      const transformedKit: ShoppingKit = {
        id: `custom-kit-${Date.now()}`,
        title: data.title || promptTheme,
        description: data.description || 'Custom tailored shopping bundle created by Aura Shopping Agent.',
        targetBudget: data.targetBudget || targetBudget,
        totalPrice: data.totalPrice || 0,
        savingsTotal: data.savingsTotal || 0,
        items: data.items.map((item: any, idx: number) => {
          // Find matching product or build proxy product
          const matched = INITIAL_PRODUCTS.find(p => p.title.toLowerCase().includes(item.title.toLowerCase())) || {
            id: `gen-kit-prod-${idx}`,
            title: item.title,
            brand: item.brand || 'Premium Brand',
            category: 'Electronics' as const,
            rating: 4.8,
            reviewCount: 1200,
            imageUrl: item.imageUrl || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=800&q=80',
            currentPrice: item.price,
            originalPrice: item.originalPrice || item.price * 1.2,
            dealScore: 92,
            dealLabel: 'Agent Bundle Deal',
            stores: [
              {
                storeName: item.store || 'Amazon',
                price: item.price,
                inStock: true,
                shipping: 'Free 2-day',
                url: 'https://amazon.com',
                condition: 'New',
                rating: 4.8,
                isLowest: true,
              }
            ],
            description: item.whyChosen || 'Curated item matching your requirements.',
            specs: { 'Kit Category': item.categoryName },
            pros: ['Excellent quality in category', 'Fits target budget seamlessly'],
            cons: ['May require basic initial setup'],
            aiVerdict: item.whyChosen,
            priceHistory: [
              { date: 'Last Month', price: item.price * 1.15 },
              { date: 'Today', price: item.price }
            ],
            coupons: [],
            tags: ['Bundle Pick', 'Curated']
          };

          return {
            categoryName: item.categoryName,
            selectedProduct: matched,
          };
        }),
      };

      // Recalculate accurate total
      transformedKit.totalPrice = transformedKit.items.reduce((sum, it) => sum + it.selectedProduct.currentPrice, 0);
      transformedKit.savingsTotal = transformedKit.items.reduce((sum, it) => sum + (it.selectedProduct.originalPrice - it.selectedProduct.currentPrice), 0);

      setActiveKit(transformedKit);
    } catch (err) {
      console.error('Build kit error:', err);
      // Fallback
      setActiveKit(PRESET_KITS[0]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddEntireKitToCart = () => {
    const itemsToAdd = currentDisplayKit.items.map(item => {
      const lowestStore = item.selectedProduct.stores.reduce((prev, curr) => curr.price < prev.price ? curr : prev, item.selectedProduct.stores[0]);
      return {
        product: item.selectedProduct,
        store: lowestStore,
      };
    });

    onAddMultipleToCart(itemsToAdd);
  };

  const budgetUsedPercentage = Math.min(
    100,
    Math.round((currentDisplayKit.totalPrice / currentDisplayKit.targetBudget) * 100)
  );

  return (
    <div className="max-w-6xl mx-auto space-y-4">
      
      {/* Hero Header */}
      <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-xl border border-slate-800 shadow-xs relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[11px] font-bold border border-emerald-500/30">
            <Sparkles className="w-3 h-3" />
            <span>Autonomous Kit & Setup Concierge</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
            Curated Gear Kits Built for Your Budget
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            Specify a use case and budget, and Aura Shopping Agent will assemble a harmonious, multi-item setup, find the lowest retailer for each item, and apply verified bundle promo codes.
          </p>
        </div>
      </div>

      {/* Preset Kit Selector & Custom Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left: Custom Prompt Builder */}
        <div className="lg:col-span-5 bg-white p-3.5 rounded-xl border border-slate-200 space-y-3 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-900 font-bold text-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-700" />
            <span>Configure AI Setup Generator</span>
          </div>

          {/* Preset Buttons */}
          <div className="space-y-1">
            <label className="text-[11px] text-slate-500 block font-medium">Choose a Popular Preset:</label>
            <div className="flex flex-col gap-1">
              {PRESET_KITS.map((kit) => (
                <button
                  key={kit.id}
                  onClick={() => {
                    setActiveKit(kit);
                    setSelectedTheme(kit.title);
                    setTargetBudget(kit.targetBudget);
                  }}
                  className={`text-left p-2 rounded-lg text-xs font-medium border transition-all flex items-center justify-between ${
                    currentDisplayKit.id === kit.id
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 shadow-xs font-semibold'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="truncate pr-2">{kit.title}</span>
                  <span className="text-emerald-700 font-bold shrink-0">${kit.totalPrice.toFixed(0)}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="relative py-0.5">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
            <div className="relative flex justify-center text-[9px] uppercase font-bold text-slate-400 bg-white px-2">OR ENTER CUSTOM SPEC</div>
          </div>

          {/* Custom Form */}
          <form onSubmit={handleGenerateCustomKit} className="space-y-2.5">
            <div>
              <label className="text-[11px] text-slate-500 block font-medium mb-1">Custom Bundle Goal / Scenario:</label>
              <input
                type="text"
                value={customTheme}
                onChange={(e) => setCustomTheme(e.target.value)}
                placeholder="e.g. Creator YouTube studio under $500, Dorm kitchen setup..."
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500 text-[11px]">Target Max Budget:</span>
                <span className="font-bold text-emerald-700">${targetBudget}</span>
              </div>
              <input
                type="range"
                min={200}
                max={2500}
                step={50}
                value={targetBudget}
                onChange={(e) => setTargetBudget(Number(e.target.value))}
                className="w-full accent-emerald-600 bg-slate-200 h-1.5 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>$200</span>
                <span>$1,000</span>
                <span>$2,500</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isGenerating}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-lg text-xs font-medium shadow-xs flex items-center justify-center gap-1.5 transition-all"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Generating Harmonized Kit...
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  Generate Custom AI Setup
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right: Active Kit Visualization */}
        <div className="lg:col-span-7 bg-white p-4 rounded-xl border border-slate-200 space-y-4 shadow-xs flex flex-col justify-between">
          
          <div className="space-y-3">
            {/* Kit Title & Summary */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Active Setup Breakdown</span>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">{currentDisplayKit.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{currentDisplayKit.description}</p>
              </div>

              <div className="text-right">
                <span className="text-xl font-bold text-slate-900">${currentDisplayKit.totalPrice.toFixed(2)}</span>
                <span className="block text-[11px] text-emerald-700 font-semibold">Total Savings: ${currentDisplayKit.savingsTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Budget Utilization Meter */}
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 text-[11px]">Budget Utilization:</span>
                <span className="font-bold text-slate-700 text-[11px]">
                  ${currentDisplayKit.totalPrice.toFixed(0)} of ${currentDisplayKit.targetBudget} ({budgetUsedPercentage}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 rounded-full ${
                    budgetUsedPercentage <= 100 ? 'bg-emerald-600' : 'bg-rose-500'
                  }`}
                  style={{ width: `${Math.min(100, budgetUsedPercentage)}%` }}
                />
              </div>
            </div>

            {/* Itemized Kit List */}
            <div className="space-y-2">
              {currentDisplayKit.items.map((item, index) => {
                const prod = item.selectedProduct;
                const lowest = prod.stores.reduce((prev, curr) => curr.price < prev.price ? curr : prev, prod.stores[0]);

                return (
                  <div
                    key={index}
                    className="p-2 rounded-lg bg-slate-50 border border-slate-100 hover:border-slate-200 transition-all flex items-center justify-between gap-2.5"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={prod.imageUrl}
                        alt={prod.title}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-lg object-cover bg-white shrink-0 cursor-pointer border border-slate-200"
                        onClick={() => onSelectProduct(prod)}
                      />
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase font-bold text-emerald-700 tracking-wider">
                          {item.categoryName}
                        </span>
                        <h4
                          onClick={() => onSelectProduct(prod)}
                          className="text-xs font-semibold text-slate-800 hover:text-emerald-700 cursor-pointer truncate max-w-[200px] sm:max-w-[260px]"
                        >
                          {prod.title}
                        </h4>
                        <span className="text-[10px] text-slate-500">
                          Lowest at <strong className="text-slate-700">{lowest.storeName}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="text-right flex items-center gap-2 shrink-0">
                      <div>
                        <span className="text-xs font-bold text-slate-900">${lowest.price.toFixed(2)}</span>
                        {prod.originalPrice > lowest.price && (
                          <span className="block text-[10px] text-slate-400 line-through">${prod.originalPrice.toFixed(2)}</span>
                        )}
                      </div>

                      <button
                        onClick={() => onAddToCart(prod, lowest)}
                        className="p-1.5 bg-white hover:bg-slate-900 hover:text-white text-slate-700 border border-slate-200 rounded-lg transition-colors shadow-xs"
                        title="Add single item to cart"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Add All Button */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
            <div className="text-[11px] text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>All {currentDisplayKit.items.length} items verified in stock across authorized sellers</span>
            </div>

            <button
              onClick={handleAddEntireKitToCart}
              className="py-2 px-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs flex items-center gap-1.5 transition-all shrink-0"
              id="btn-add-entire-kit"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
              Add Entire Kit (${currentDisplayKit.totalPrice.toFixed(0)})
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
