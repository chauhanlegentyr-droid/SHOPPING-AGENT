import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  ShoppingBag, 
  Scale, 
  Bell, 
  ArrowRight, 
  CheckCircle2, 
  Loader2, 
  RotateCcw, 
  Mic, 
  MicOff,
  Zap,
  Tag,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { AgentMessage, Product, StorePrice } from '../types';

interface AgentChatProps {
  messages: AgentMessage[];
  onSendMessage: (text: string) => Promise<void>;
  isLoading: boolean;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, store: StorePrice) => void;
  onToggleCompare: (product: Product) => void;
  onSetPriceAlert: (product: Product) => void;
  onQuickPromptClick: (prompt: string) => void;
  onResetChat: () => void;
}

export const AgentChat: React.FC<AgentChatProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onSelectProduct,
  onAddToCart,
  onToggleCompare,
  onSetPriceAlert,
  onQuickPromptClick,
  onResetChat,
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const SUGGESTED_PROMPTS = [
    'Find best wireless noise-canceling headphones under $350',
    'Compare Sony WH-1000XM5 vs Apple MacBook Air M3 specs and value',
    'Build a high-productivity home office desk setup for under $700',
    'Find active promo codes and discounts for Nike running shoes',
    'Which store currently has the lowest price on Dyson V15 vacuum?'
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;
    const text = inputValue.trim();
    setInputValue('');
    await onSendMessage(text);
  };

  // Speech Recognition handler if supported
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please type your query.');
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsRecording(true);
      recognition.onend = () => setIsRecording(false);
      recognition.onerror = () => setIsRecording(false);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsRecording(false);
      };

      recognition.start();
    } catch (err) {
      console.error(err);
      setIsRecording(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-6.5rem)] max-w-5xl mx-auto bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      
      {/* Chat Header */}
      <div className="px-3.5 py-2.5 border-b border-slate-200 bg-white flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center shadow-xs">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-bold text-slate-900 text-sm">Aura AI Shopping Assistant</h2>
              <span className="px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Live Multimodal Shopper
              </span>
            </div>
            <p className="text-[11px] text-slate-500">Autonomous deal finding, cross-store comparison, price tracking & kit building</p>
          </div>
        </div>

        <button
          onClick={onResetChat}
          title="Reset conversation"
          className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors text-xs flex items-center gap-1 font-medium"
        >
          <RotateCcw className="w-3 h-3" />
          <span>New Session</span>
        </button>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
        
        {/* Welcome Banner if only initial message */}
        {messages.length <= 1 && (
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>What would you like to find, compare, or buy today?</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              I can scan multiple retailers simultaneously, analyze hundreds of verified reviews, calculate true deal scores, test active coupon codes, and build optimized setups for any budget.
            </p>
            
            {/* Quick Prompt Pills */}
            <div className="pt-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">Try asking:</span>
              <div className="flex flex-wrap gap-1.5">
                {SUGGESTED_PROMPTS.map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => onQuickPromptClick(prompt)}
                    className="text-left text-[11px] px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 hover:text-emerald-700 border border-slate-200 transition-all flex items-center gap-1 shadow-xs"
                  >
                    <Zap className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                    <span>{prompt}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Message List */}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'agent' && (
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0 shadow-xs">
                <Bot className="w-3.5 h-3.5 text-white" />
              </div>
            )}

            <div
              className={`max-w-[88%] sm:max-w-[82%] space-y-2 ${
                msg.sender === 'user'
                  ? 'bg-slate-900 text-white rounded-xl rounded-tr-xs px-3.5 py-2.5 shadow-xs text-xs'
                  : 'bg-slate-50 text-slate-900 rounded-xl rounded-tl-xs px-3.5 py-3 border border-slate-200 shadow-xs text-xs'
              }`}
            >
              {/* Tool Invocations Status if any */}
              {msg.toolInvocations && msg.toolInvocations.length > 0 && (
                <div className="space-y-1 pb-1.5 border-b border-slate-200">
                  {msg.toolInvocations.map((tool, tIdx) => (
                    <div key={tIdx} className="flex items-center gap-1 text-[10px] text-emerald-700 font-semibold">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                      <span>{tool.tool}: <strong className="text-slate-700 font-normal">{tool.summary}</strong></span>
                    </div>
                  ))}
                </div>
              )}

              {/* Message Text with simple linebreaks */}
              <div className="text-xs leading-relaxed whitespace-pre-wrap">
                {msg.text}
              </div>

              {/* Embedded Actionable Product Cards */}
              {msg.products && msg.products.length > 0 && (
                <div className="pt-1.5 space-y-1.5">
                  <div className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                    <ShoppingBag className="w-3 h-3" />
                    <span>Recommended Items:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {msg.products.map((prod) => {
                      const lowest = prod.stores.reduce((prev, curr) => curr.price < prev.price ? curr : prev, prod.stores[0]);
                      return (
                        <div
                          key={prod.id}
                          className="bg-white border border-slate-200 rounded-lg p-2 space-y-1.5 hover:border-slate-300 transition-all flex flex-col justify-between shadow-xs"
                        >
                          <div className="flex gap-2">
                            <img
                              src={prod.imageUrl}
                              alt={prod.title}
                              referrerPolicy="no-referrer"
                              className="w-12 h-12 rounded-lg object-cover bg-slate-100 shrink-0 cursor-pointer"
                              onClick={() => onSelectProduct(prod)}
                            />
                            <div className="flex-1 min-w-0">
                              <h4
                                onClick={() => onSelectProduct(prod)}
                                className="text-xs font-semibold text-slate-900 truncate cursor-pointer hover:text-emerald-600"
                              >
                                {prod.title}
                              </h4>
                              <p className="text-[10px] text-slate-500 truncate">{prod.brand} • {prod.rating} ★ ({prod.reviewCount})</p>
                              <div className="flex items-baseline gap-1 mt-0.5">
                                <span className="text-xs font-bold text-slate-900">${prod.currentPrice.toFixed(2)}</span>
                                <span className="text-[10px] text-slate-400 line-through">${prod.originalPrice.toFixed(2)}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 pt-1 border-t border-slate-100">
                            <button
                              onClick={() => onAddToCart(prod, lowest)}
                              className="flex-1 py-1 px-2 bg-slate-900 hover:bg-slate-800 text-white rounded text-[10px] font-medium flex items-center justify-center gap-1"
                            >
                              <ShoppingBag className="w-2.5 h-2.5 text-emerald-400" />
                              Add
                            </button>
                            <button
                              onClick={() => onSelectProduct(prod)}
                              className="py-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] font-medium"
                            >
                              Inspect
                            </button>
                            <button
                              onClick={() => onToggleCompare(prod)}
                              title="Compare"
                              className="p-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded"
                            >
                              <Scale className="w-3 h-3 text-indigo-600" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                <div className="pt-1 flex flex-wrap gap-1">
                  {msg.suggestedActions.map((action, aIdx) => (
                    <button
                      key={aIdx}
                      onClick={() => onQuickPromptClick(action.label)}
                      className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 hover:text-emerald-700 text-[11px] font-medium transition-colors flex items-center gap-1 shadow-xs"
                    >
                      <ArrowRight className="w-2.5 h-2.5 text-emerald-600" />
                      <span>{action.label}</span>
                    </button>
                  ))}
                </div>
              )}

              <span className="text-[10px] text-slate-400 block text-right pt-0.5">
                {msg.timestamp}
              </span>
            </div>

            {msg.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center shrink-0 shadow-xs">
                <span className="text-[10px] font-bold text-white">You</span>
              </div>
            )}
          </div>
        ))}

        {/* Thinking Indicator */}
        {isLoading && (
          <div className="flex gap-2.5 justify-start items-center">
            <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="bg-slate-50 rounded-xl px-3 py-2 border border-slate-200 flex items-center gap-2 text-xs text-slate-600">
              <Loader2 className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
              <span>Aura Agent is scanning retailer catalogs, pricing trends, and review data...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="p-2.5 bg-white border-t border-slate-200">
        <form onSubmit={handleSubmit} className="relative flex items-center gap-1.5">
          <div className="relative flex-1">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask anything: 'Find me the best noise-canceling headphones under $300' or 'Compare X vs Y'..."
              className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 transition-all shadow-xs"
              disabled={isLoading}
              id="agent-chat-input"
            />
            
            {/* Mic button */}
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              title={isRecording ? 'Listening...' : 'Voice Input'}
              className={`absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded transition-colors ${
                isRecording ? 'bg-rose-500 text-white animate-pulse' : 'text-slate-400 hover:text-emerald-600'
              }`}
            >
              {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="p-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg shadow-xs transition-all active:scale-95 flex items-center justify-center shrink-0"
            id="btn-send-agent-message"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

    </div>
  );
};
