import React from 'react';
import { 
  Bot, 
  ShoppingBag, 
  Scale, 
  Package, 
  Bell, 
  Receipt, 
  Camera, 
  Search, 
  Sparkles,
  Zap
} from 'lucide-react';
import { ViewMode } from '../types';

interface NavbarProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  compareCount: number;
  alertCount: number;
  orderCount: number;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearchSubmit: (e: React.FormEvent) => void;
  onOpenVisualSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onViewChange,
  cartCount,
  cartTotal,
  onOpenCart,
  compareCount,
  alertCount,
  orderCount,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onOpenVisualSearch,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-900">
      {/* Top Notification Bar */}
      <div className="bg-slate-900 px-4 py-1 text-[11px] sm:text-xs font-medium text-center text-slate-200 flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
        <span>Aura AI Shopping Agent Active — Monitoring 14+ Retailers for Real-time Price Drops & Hidden Promo Codes</span>
        <span className="hidden sm:inline-block bg-slate-800 text-emerald-400 border border-slate-700 px-1.5 py-0.2 rounded text-[10px] font-semibold">Live Feed</span>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-6">
        <div className="flex items-center justify-between h-14 gap-3">
          
          {/* Brand Logo & Name */}
          <div 
            onClick={() => onViewChange('catalog')}
            className="flex items-center gap-2.5 cursor-pointer select-none group shrink-0"
            id="brand-logo"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center shadow-xs group-hover:bg-emerald-700 transition-colors">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-slate-900 group-hover:text-emerald-700 transition-colors">
                  Aura<span className="text-emerald-600 font-semibold ml-0.5">Agent</span>
                </span>
                <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  AI 3.7
                </span>
              </div>
              <p className="text-[10px] text-slate-500 leading-none">Autonomous Shopping & Price Concierge</p>
            </div>
          </div>

          {/* Search Bar with Visual Search Action */}
          <div className="flex-1 max-w-lg hidden md:block">
            <form onSubmit={onSearchSubmit} className="relative flex items-center">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-3.5 h-3.5" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search products, compare models, paste URL or describe need..."
                className="w-full pl-9 pr-22 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 transition-all shadow-xs"
                id="global-search-input"
              />
              <div className="absolute right-1 flex items-center gap-1">
                <button
                  type="button"
                  onClick={onOpenVisualSearch}
                  title="Visual & URL Search (Image / Link)"
                  className="p-1 rounded text-slate-400 hover:text-emerald-600 hover:bg-slate-100 transition-colors"
                  id="btn-visual-search"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
                <button
                  type="submit"
                  className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-[11px] font-medium shadow-xs transition-colors flex items-center gap-1"
                  id="btn-submit-search"
                >
                  <Zap className="w-2.5 h-2.5 text-emerald-400" />
                  Search
                </button>
              </div>
            </form>
          </div>

          {/* Navigation Links & Action Buttons */}
          <nav className="flex items-center gap-1 sm:gap-1.5">
            
            {/* AI Shopper Tab */}
            <button
              onClick={() => onViewChange('agent')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                currentView === 'agent'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              id="nav-tab-agent"
            >
              <Bot className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">AI Shopper</span>
            </button>

            {/* Catalog Tab */}
            <button
              onClick={() => onViewChange('catalog')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                currentView === 'catalog'
                  ? 'bg-slate-100 text-slate-900 border border-slate-200 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              id="nav-tab-catalog"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Products</span>
            </button>

            {/* Compare Tab */}
            <button
              onClick={() => onViewChange('compare')}
              className={`relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                currentView === 'compare'
                  ? 'bg-slate-100 text-slate-900 border border-slate-200 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              id="nav-tab-compare"
            >
              <Scale className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Compare</span>
              {compareCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center">
                  {compareCount}
                </span>
              )}
            </button>

            {/* Bundles / Kits Tab */}
            <button
              onClick={() => onViewChange('kits')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                currentView === 'kits'
                  ? 'bg-slate-100 text-slate-900 border border-slate-200 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              id="nav-tab-kits"
            >
              <Package className="w-3.5 h-3.5 text-teal-600" />
              <span className="hidden sm:inline">Setups & Kits</span>
            </button>

            {/* Price Alerts */}
            <button
              onClick={() => onViewChange('alerts')}
              className={`relative p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors ${
                currentView === 'alerts' ? 'bg-slate-100 text-slate-900 border border-slate-200' : ''
              }`}
              title="Price Watch & Alerts"
              id="nav-btn-alerts"
            >
              <Bell className="w-4 h-4 text-amber-500" />
              {alertCount > 0 && (
                <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white"></span>
              )}
            </button>

            {/* Order History */}
            <button
              onClick={() => onViewChange('orders')}
              className={`p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors ${
                currentView === 'orders' ? 'bg-slate-100 text-slate-900 border border-slate-200' : ''
              }`}
              title="Autonomous Orders & Receipts"
              id="nav-btn-orders"
            >
              <Receipt className="w-4 h-4 text-sky-600" />
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-all hover:scale-[1.02] active:scale-[0.98]"
              id="nav-btn-cart"
            >
              <div className="relative">
                <ShoppingBag className="w-3.5 h-3.5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-amber-400 text-slate-950 font-bold text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline">
                {cartTotal > 0 ? `$${cartTotal.toFixed(2)}` : 'Cart'}
              </span>
            </button>

          </nav>
        </div>

        {/* Mobile Search Input */}
        <div className="pb-2.5 md:hidden">
          <form onSubmit={onSearchSubmit} className="relative flex items-center">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search products or ask AI shopper..."
              className="w-full pl-8 pr-18 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
              id="mobile-search-input"
            />
            <div className="absolute right-1 flex items-center gap-1">
              <button
                type="button"
                onClick={onOpenVisualSearch}
                className="p-1 rounded text-slate-400 hover:text-emerald-600"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
              <button
                type="submit"
                className="px-2 py-0.5 bg-slate-900 text-white rounded text-[11px] font-medium"
              >
                Search
              </button>
            </div>
          </form>
        </div>

      </div>
    </header>
  );
};
