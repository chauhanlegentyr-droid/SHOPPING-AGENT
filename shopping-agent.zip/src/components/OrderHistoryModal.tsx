import React from 'react';
import { 
  Receipt, 
  CheckCircle2, 
  Truck, 
  Package, 
  ExternalLink, 
  Calendar, 
  ShieldCheck, 
  ShoppingBag 
} from 'lucide-react';
import { Order } from '../types';

interface OrderHistoryModalProps {
  orders: Order[];
  onOpenCatalog: () => void;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({
  orders,
  onOpenCatalog,
}) => {
  const totalLifetimeSavings = orders.reduce((sum, o) => sum + o.totalSavings, 0);

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      
      {/* Header */}
      <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-sky-600" />
            <h2 className="text-base font-bold text-slate-900">Autonomous Order History & Receipts</h2>
            <span className="px-1.5 py-0.2 rounded bg-sky-50 text-sky-700 text-[10px] font-bold border border-sky-200">
              {orders.length} Orders
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            All orders executed through Aura AI Shopper with automated coupon locks and price-drop protection.
          </p>
        </div>

        <div className="text-left sm:text-right bg-slate-50 p-2 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 block">Total Lifetime Savings</span>
          <span className="text-base font-bold text-emerald-700">${totalLifetimeSavings.toFixed(2)}</span>
        </div>
      </div>

      {/* Orders List */}
      {orders.length === 0 ? (
        <div className="text-center py-12 px-4 bg-white rounded-xl border border-slate-200 space-y-2 shadow-xs">
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-sky-600 mx-auto flex items-center justify-center">
            <Receipt className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">No Orders Placed Yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            When you purchase items via Universal Cart or Autonomous 1-Click Checkout, verified order receipts will appear here.
          </p>
          <button
            onClick={onOpenCatalog}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium transition-all shadow-xs"
          >
            Start Shopping
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {orders.map((order) => (
            <div
              key={order.id}
              className="p-3 rounded-lg bg-white border border-slate-200 space-y-2.5 shadow-xs"
            >
              {/* Order Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-slate-200 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-slate-900 text-xs">#{order.id}</span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        {order.status}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.2">
                      <Calendar className="w-2.5 h-2.5" /> {order.date}
                    </span>
                  </div>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-sm font-bold text-slate-900">${order.totalAmount.toFixed(2)}</span>
                  <span className="text-[11px] text-emerald-700 block font-medium">Saved ${order.totalSavings.toFixed(2)}</span>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-1">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between gap-2 text-xs bg-slate-50 p-1.5 rounded-md border border-slate-200">
                    <div className="flex items-center gap-2">
                      <img
                        src={item.productImage}
                        alt={item.productTitle}
                        referrerPolicy="no-referrer"
                        className="w-7 h-7 rounded object-cover bg-white border border-slate-200"
                      />
                      <span className="text-slate-700 font-medium truncate max-w-[240px] sm:max-w-[340px] text-[11px]">
                        {item.quantity}x {item.productTitle} <span className="text-slate-400">({item.storeName})</span>
                      </span>
                    </div>
                    <span className="font-bold text-slate-900 text-xs">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              {/* Footer info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pt-1.5 border-t border-slate-200 text-[10px] text-slate-500">
                <div className="flex items-center gap-1">
                  <Truck className="w-3 h-3 text-emerald-700" />
                  <span>Tracking: <strong className="font-mono text-slate-800">{order.trackingNumber}</strong></span>
                </div>
                <div className="flex items-center gap-1 text-emerald-700 font-medium">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{order.agentNotes}</span>
                </div>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
