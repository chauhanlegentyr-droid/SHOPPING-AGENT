import React from 'react';
import { 
  Star, 
  Tag, 
  TrendingDown, 
  Scale, 
  Bell, 
  Bot, 
  ShoppingBag, 
  Check, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { Product, StorePrice } from '../types';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, store: StorePrice) => void;
  onToggleCompare: (product: Product) => void;
  isComparing: boolean;
  onSetPriceAlert: (product: Product) => void;
  isAlertSet: boolean;
  onAskAgentAboutProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelectProduct,
  onAddToCart,
  onToggleCompare,
  isComparing,
  onSetPriceAlert,
  isAlertSet,
  onAskAgentAboutProduct,
}) => {
  // Find lowest store
  const lowestStore = product.stores.reduce((prev, curr) => 
    curr.price < prev.price ? curr : prev, product.stores[0]
  );

  const discountPercent = Math.round(
    ((product.originalPrice - product.currentPrice) / product.originalPrice) * 100
  );

  const savingsAmount = (product.originalPrice - product.currentPrice).toFixed(2);

  return (
    <div 
      className="group relative bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all flex flex-col overflow-hidden"
      id={`product-card-${product.id}`}
    >
      {/* Top Media & Badges */}
      <div className="relative aspect-[16/11] w-full overflow-hidden bg-slate-100 cursor-pointer" onClick={() => onSelectProduct(product)}>
        <img
          src={product.imageUrl}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-300"
          loading="lazy"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent pointer-events-none" />

        {/* Top Badges */}
        <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-1 pointer-events-none">
          {discountPercent > 0 ? (
            <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold shadow-xs">
              <TrendingDown className="w-3 h-3" />
              {discountPercent}% OFF
            </span>
          ) : (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-100 text-[10px] font-medium">
              MSRP
            </span>
          )}

          {/* Deal Score Badge */}
          <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/95 border border-emerald-300 text-emerald-700 text-[10px] font-bold shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Score {product.dealScore}</span>
          </div>
        </div>

        {/* Deal Tag / Deal Label */}
        {product.dealLabel && (
          <div className="absolute bottom-2 left-2">
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 text-[10px] font-bold shadow-xs">
              <Tag className="w-2.5 h-2.5" />
              {product.dealLabel}
            </span>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-3 flex-1 flex flex-col justify-between space-y-2.5">
        
        {/* Brand, Category & Title */}
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-0.5">
            <span className="font-bold uppercase tracking-wider text-emerald-700">{product.brand}</span>
            <div className="flex items-center gap-0.5 text-amber-500">
              <Star className="w-3 h-3 fill-current" />
              <span className="font-bold text-slate-800">{product.rating}</span>
              <span className="text-slate-400 text-[10px]">({product.reviewCount.toLocaleString()})</span>
            </div>
          </div>

          <h3 
            onClick={() => onSelectProduct(product)}
            className="text-xs font-semibold text-slate-800 line-clamp-2 hover:text-emerald-600 transition-colors cursor-pointer leading-snug"
          >
            {product.title}
          </h3>
        </div>

        {/* Pricing Section */}
        <div className="bg-slate-50 rounded-lg p-2 border border-slate-100">
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-bold text-slate-900 tracking-tight">
                ${product.currentPrice.toFixed(2)}
              </span>
              {product.originalPrice > product.currentPrice && (
                <span className="text-xs text-slate-400 line-through">
                  ${product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            {Number(savingsAmount) > 0 && (
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-100">
                Save ${savingsAmount}
              </span>
            )}
          </div>

          {/* Store Pill */}
          <div className="mt-1 pt-1 border-t border-slate-200/60 flex items-center justify-between text-[10px]">
            <span className="text-slate-500 flex items-center gap-1">
              Lowest at <strong className="text-slate-700 font-semibold">{lowestStore.storeName}</strong>
            </span>
            <span className="text-emerald-700 font-medium truncate max-w-[110px]">
              {lowestStore.shipping}
            </span>
          </div>
        </div>

        {/* AI Insight Snippet */}
        <div className="bg-emerald-50/70 rounded-md p-1.5 border border-emerald-100 text-[10px] text-slate-700 flex items-start gap-1">
          <Bot className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
          <p className="line-clamp-2 leading-tight">
            <strong className="text-emerald-800">Verdict:</strong> {product.aiVerdict}
          </p>
        </div>

        {/* Quick Action Strip */}
        <div className="pt-1 flex items-center gap-1">
          
          {/* Main Add to Cart */}
          <button
            onClick={() => onAddToCart(product, lowestStore)}
            className="flex-1 py-1.5 px-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white rounded-lg text-xs font-medium transition-all shadow-xs flex items-center justify-center gap-1"
            id={`btn-add-cart-${product.id}`}
          >
            <ShoppingBag className="w-3 h-3 text-emerald-400" />
            Add (${lowestStore.price.toFixed(0)})
          </button>

          {/* Ask AI Shopper */}
          <button
            onClick={() => onAskAgentAboutProduct(product)}
            title="Ask AI Shopper to analyze or find cheaper dupes"
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-emerald-700 border border-slate-200 transition-colors"
            id={`btn-ask-ai-${product.id}`}
          >
            <Bot className="w-3.5 h-3.5" />
          </button>

          {/* Toggle Compare */}
          <button
            onClick={() => onToggleCompare(product)}
            title={isComparing ? 'Remove from compare' : 'Add to side-by-side compare'}
            className={`p-1.5 rounded-lg border transition-colors ${
              isComparing
                ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-indigo-700 border-slate-200'
            }`}
            id={`btn-compare-${product.id}`}
          >
            <Scale className="w-3.5 h-3.5" />
          </button>

          {/* Toggle Price Alert */}
          <button
            onClick={() => onSetPriceAlert(product)}
            title={isAlertSet ? 'Price Alert Active' : 'Set Price Drop Alert'}
            className={`p-1.5 rounded-lg border transition-colors ${
              isAlertSet
                ? 'bg-amber-50 border-amber-300 text-amber-700'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-amber-700 border-slate-200'
            }`}
            id={`btn-alert-${product.id}`}
          >
            <Bell className="w-3.5 h-3.5" />
          </button>

        </div>

      </div>
    </div>
  );
};
