import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  Zap, 
  Check, 
  Tag, 
  ArrowRight, 
  ShieldCheck, 
  Loader2, 
  Sparkles,
  Truck
} from 'lucide-react';
import { CartItem, Coupon } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, storeName: string, delta: number) => void;
  onRemoveItem: (productId: string, storeName: string) => void;
  onClearCart: () => void;
  onOpenCheckout: (appliedDiscountTotal: number) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOpenCheckout,
}) => {
  const [isTestingCoupons, setIsTestingCoupons] = useState(false);
  const [couponTestProgress, setCouponTestProgress] = useState(0);
  const [currentTestingCode, setCurrentTestingCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.selectedStore.price * item.quantity, 0
  );

  const originalSubtotal = cartItems.reduce(
    (sum, item) => sum + (item.product.originalPrice || item.selectedStore.price) * item.quantity, 0
  );

  const baseSavings = Math.max(0, originalSubtotal - subtotal);
  
  // Extra coupon discount if applied
  const couponDiscountAmount = appliedCoupon 
    ? (appliedCoupon.discountType === 'percentage'
        ? (subtotal * (appliedCoupon.discountAmount || 10)) / 100
        : (appliedCoupon.discountAmount || 15))
    : 0;

  const totalDiscount = baseSavings + couponDiscountAmount;
  const estimatedTax = (subtotal - couponDiscountAmount) * 0.075;
  const finalTotal = Math.max(0, subtotal - couponDiscountAmount + estimatedTax);

  // Honey-style automated coupon scanner
  const handleAutoTestCoupons = async () => {
    setIsTestingCoupons(true);
    setCouponTestProgress(0);

    const CODES_TO_TEST = [
      'AGENTVIP10',
      'WELCOME20',
      'SAVEMORE15',
      'SUMMERDEAL25',
      'HOLIDAYBOOST',
      'AURASHOP20'
    ];

    for (let i = 0; i < CODES_TO_TEST.length; i++) {
      setCurrentTestingCode(CODES_TO_TEST[i]);
      setCouponTestProgress(Math.round(((i + 1) / CODES_TO_TEST.length) * 100));
      await new Promise((resolve) => setTimeout(resolve, 450));
    }

    // Apply best winning coupon
    const winningCoupon: Coupon = {
      code: 'AURASHOP20',
      discountDescription: '20% Agent Verified Multi-Store Instant Credit',
      discountAmount: 20,
      discountType: 'percentage',
      store: 'Universal Cart',
      successRate: 99,
      verifiedDate: 'Verified just now'
    };

    setAppliedCoupon(winningCoupon);
    setIsTestingCoupons(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div 
        className="absolute inset-y-0 right-0 max-w-full flex pl-8"
        id="cart-drawer-container"
      >
        <div className="w-screen max-w-md bg-white border-l border-slate-200 text-slate-900 flex flex-col shadow-xl">
          
          {/* Header */}
          <div className="p-3 sm:p-4 border-b border-slate-200 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center border border-slate-200">
                <ShoppingBag className="w-3.5 h-3.5" />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 text-sm">Universal Smart Cart</h2>
                <p className="text-[11px] text-slate-500">
                  {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} across authorized sellers
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
              id="btn-close-cart"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Cart Body */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3">
            
            {cartItems.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">Your Cart is Currently Empty</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Browse curated products or ask Aura AI Shopper to find deals and auto-add items to your cart.
                </p>
              </div>
            ) : (
              <>
                {/* Item List */}
                <div className="space-y-2">
                  {cartItems.map((item, idx) => (
                    <div
                      key={`${item.product.id}-${item.selectedStore.storeName}-${idx}`}
                      className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2"
                    >
                      <div className="flex gap-2.5">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.title}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-lg object-cover bg-white shrink-0 border border-slate-200"
                        />
                        <div className="flex-1 min-w-0">
                          <span className="text-[9px] uppercase font-bold text-emerald-700 tracking-wider">
                            Store: {item.selectedStore.storeName}
                          </span>
                          <h4 className="text-xs font-semibold text-slate-900 truncate">{item.product.title}</h4>
                          <p className="text-[10px] text-slate-500">{item.selectedStore.shipping}</p>
                          
                          <div className="flex items-baseline gap-1.5 mt-0.5">
                            <span className="text-xs font-bold text-slate-900">
                              ${item.selectedStore.price.toFixed(2)}
                            </span>
                            {item.product.originalPrice > item.selectedStore.price && (
                              <span className="text-[10px] text-slate-400 line-through">
                                ${item.product.originalPrice.toFixed(2)}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Quantity and Remove Toolbar */}
                      <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded p-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.selectedStore.storeName, -1)}
                            className="p-0.5 text-slate-500 hover:text-slate-900 rounded"
                          >
                            <Minus className="w-2.5 h-2.5" />
                          </button>
                          <span className="text-xs font-bold px-1.5 text-slate-800">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.selectedStore.storeName, 1)}
                            className="p-0.5 text-slate-500 hover:text-slate-900 rounded"
                          >
                            <Plus className="w-2.5 h-2.5" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id, item.selectedStore.storeName)}
                          className="text-[11px] text-rose-600 hover:text-rose-800 flex items-center gap-1 transition-colors"
                        >
                          <Trash2 className="w-3 h-3" />
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Auto-Apply Coupons Scanner Tool */}
                <div className="p-3 rounded-lg bg-indigo-50/70 border border-indigo-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-xs font-bold text-indigo-900">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      <span>AI Coupon & Promo Scanner</span>
                    </div>

                    {appliedCoupon && (
                      <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        Applied -${couponDiscountAmount.toFixed(2)}
                      </span>
                    )}
                  </div>

                  {isTestingCoupons ? (
                    <div className="space-y-1.5 py-0.5">
                      <div className="flex justify-between text-xs text-slate-700">
                        <span className="text-[11px]">Testing code: <strong className="font-mono text-indigo-900">{currentTestingCode}</strong></span>
                        <span className="text-[11px]">{couponTestProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full transition-all duration-300"
                          style={{ width: `${couponTestProgress}%` }}
                        />
                      </div>
                    </div>
                  ) : appliedCoupon ? (
                    <div className="text-xs text-emerald-800 flex items-center justify-between">
                      <span className="text-[11px]">Code <strong>{appliedCoupon.code}</strong> applied (saved 20%)</span>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    </div>
                  ) : (
                    <button
                      onClick={handleAutoTestCoupons}
                      className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-medium shadow-xs transition-all flex items-center justify-center gap-1"
                      id="btn-auto-test-coupons"
                    >
                      <Zap className="w-3 h-3" />
                      Auto-Test Best Promo Codes
                    </button>
                  )}
                </div>
              </>
            )}

          </div>

          {/* Cart Footer */}
          {cartItems.length > 0 && (
            <div className="p-3 sm:p-4 border-t border-slate-200 bg-white space-y-2.5">
              <div className="space-y-1 text-xs text-slate-500">
                <div className="flex justify-between text-[11px]">
                  <span>MSRP Subtotal:</span>
                  <span className="line-through">${originalSubtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[11px] text-emerald-700 font-semibold">
                  <span>Retailer Deals & Markdowns:</span>
                  <span>-${baseSavings.toFixed(2)}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-[11px] text-emerald-700 font-semibold">
                    <span>Coupon ({appliedCoupon.code}):</span>
                    <span>-${couponDiscountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[11px]">
                  <span>Estimated Tax (7.5%):</span>
                  <span>${estimatedTax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span>Shipping:</span>
                  <span className="text-emerald-700 font-semibold">FREE</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-1.5 border-t border-slate-100">
                  <span>Final Total:</span>
                  <span>${finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={() => onOpenCheckout(couponDiscountAmount)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs flex items-center justify-center gap-1.5 transition-all"
                id="btn-checkout-now"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Autonomous 1-Click Checkout (${finalTotal.toFixed(2)})
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
