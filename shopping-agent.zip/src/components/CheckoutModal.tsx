import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  Loader2, 
  Sparkles, 
  Truck, 
  CreditCard, 
  Receipt, 
  ExternalLink,
  Bot
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  couponDiscount: number;
  onOrderPlaced: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  couponDiscount,
  onOrderPlaced,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Form mock state
  const [address, setAddress] = useState('742 Evergreen Terrace, San Francisco, CA 94107');
  const [paymentMethod, setPaymentMethod] = useState('Apple Pay / Agent Smart Escrow');

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.selectedStore.price * item.quantity, 0
  );
  const originalSubtotal = cartItems.reduce(
    (sum, item) => sum + (item.product.originalPrice || item.selectedStore.price) * item.quantity, 0
  );
  const baseSavings = Math.max(0, originalSubtotal - subtotal);
  const totalSavings = baseSavings + couponDiscount;
  const estimatedTax = (subtotal - couponDiscount) * 0.075;
  const finalTotal = Math.max(0, subtotal - couponDiscount + estimatedTax);

  const STEPS = [
    'Verifying multi-retailer inventory & reserving SKUs...',
    'Securing deepest verified promotional codes...',
    'Optimizing consolidated 2-day delivery routing...',
    'Executing encrypted agent tokenized checkout...'
  ];

  const handleStartAutonomousCheckout = async () => {
    setIsProcessing(true);
    setCurrentStep(0);

    for (let i = 0; i < STEPS.length; i++) {
      setCurrentStep(i);
      await new Promise(r => setTimeout(r, 650));
    }

    const newOrder: Order = {
      id: `ORD-${Date.now().toString().slice(-6)}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      items: cartItems.map(item => ({
        productTitle: item.product.title,
        productImage: item.product.imageUrl,
        storeName: item.selectedStore.storeName,
        price: item.selectedStore.price,
        quantity: item.quantity
      })),
      totalSavings,
      totalAmount: finalTotal,
      shippingAddress: address,
      status: 'Confirmed',
      agentNotes: 'Purchased with automated price-drop guarantee and 20% coupon credit.',
      trackingNumber: `TRK-AURA-${Math.floor(10000000 + Math.random() * 90000000)}`
    };

    setCompletedOrder(newOrder);
    setIsProcessing(false);
    onOrderPlaced(newOrder);

    // Celebration confetti!
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div 
        className="relative bg-white border border-slate-200 rounded-xl max-w-lg w-full overflow-hidden shadow-xl flex flex-col text-slate-900"
        id="checkout-modal"
      >
        {/* Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-sm">
                {completedOrder ? 'Autonomous Order Confirmed' : 'Aura Autonomous Purchasing Assistant'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {completedOrder ? `Order #${completedOrder.id}` : 'Secure Multi-Store Checkout Engine'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          
          {completedOrder ? (
            /* Confirmed Order State */
            <div className="space-y-4 text-center py-2 animate-in zoom-in-95 duration-300">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 mx-auto flex items-center justify-center shadow-xs">
                <CheckCircle2 className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900">Purchase Successfully Executed!</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Aura Agent placed the orders across authorized retailers and locked in your savings of <strong className="text-emerald-700">${completedOrder.totalSavings.toFixed(2)}</strong>.
                </p>
              </div>

              {/* Receipt Summary Card */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-left space-y-2">
                <div className="flex justify-between items-center text-xs pb-1.5 border-b border-slate-200">
                  <span className="text-slate-500 text-[11px]">Tracking Code:</span>
                  <span className="font-mono font-bold text-emerald-700 text-xs">{completedOrder.trackingNumber}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Items ({completedOrder.items.length}):</span>
                  {completedOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-700 truncate max-w-[240px]">
                        {item.quantity}x {item.productTitle} <span className="text-slate-400">({item.storeName})</span>
                      </span>
                      <span className="font-semibold text-slate-900">${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-1.5 border-t border-slate-200 flex justify-between items-baseline text-xs font-bold">
                  <span className="text-slate-700">Total Billed:</span>
                  <span className="text-slate-900 text-sm">${completedOrder.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs transition-all"
              >
                Close & Return to Shopping
              </button>
            </div>
          ) : isProcessing ? (
            /* Active Autonomous Checkout Progress */
            <div className="py-6 space-y-4 text-center">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 mx-auto flex items-center justify-center animate-pulse">
                <Bot className="w-6 h-6" />
              </div>

              <div className="space-y-1">
                <h3 className="font-bold text-slate-900 text-sm">Aura Agent Executing Checkout...</h3>
                <p className="text-xs text-emerald-700 font-medium">{STEPS[currentStep]}</p>
              </div>

              {/* Progress Steps Indicator */}
              <div className="space-y-1.5 max-w-xs mx-auto text-left">
                {STEPS.map((step, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-[11px]">
                    {idx < currentStep ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    ) : idx === currentStep ? (
                      <Loader2 className="w-3.5 h-3.5 text-amber-500 animate-spin shrink-0" />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-300 shrink-0" />
                    )}
                    <span className={idx <= currentStep ? 'text-slate-800 font-medium' : 'text-slate-400'}>
                      {step}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Pre-checkout Confirmation Form */
            <div className="space-y-3.5">
              
              {/* Order Items Overview */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-700 block">Universal Order Items ({cartItems.length}):</span>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-700 truncate max-w-[220px] sm:max-w-[280px]">
                        {item.quantity}x {item.product.title}
                      </span>
                      <span className="text-slate-500">
                        ${(item.selectedStore.price * item.quantity).toFixed(2)} ({item.selectedStore.storeName})
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shipping Address */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-600 font-semibold flex items-center gap-1">
                  <Truck className="w-3 h-3 text-emerald-700" />
                  <span>Consolidated Shipping Destination</span>
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Payment Method Selection */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-600 font-semibold flex items-center gap-1">
                  <CreditCard className="w-3 h-3 text-indigo-600" />
                  <span>Tokenized Autonomous Payment Method</span>
                </label>
                <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-800">{paymentMethod}</span>
                  <span className="text-emerald-700 text-[10px] font-bold">Encrypted 256-bit</span>
                </div>
              </div>

              {/* Total & Savings Callout */}
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-slate-500 block">Total Savings Locked In:</span>
                  <span className="text-sm font-bold text-emerald-800">${totalSavings.toFixed(2)}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">Total to Authorize:</span>
                  <span className="text-base font-bold text-slate-900">${finalTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Action */}
              <button
                onClick={handleStartAutonomousCheckout}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs flex items-center justify-center gap-1.5 transition-all"
                id="btn-confirm-autonomous-checkout"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Authorize Agent to Execute Order (${finalTotal.toFixed(2)})
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
