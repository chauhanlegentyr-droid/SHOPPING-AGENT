import React, { useState } from 'react';
import { 
  Bell, 
  Trash2, 
  TrendingDown, 
  Check, 
  Sparkles, 
  Zap, 
  ShoppingBag, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { PriceAlert, Product } from '../types';

interface PriceWatchModalProps {
  alerts: PriceAlert[];
  onRemoveAlert: (alertId: string) => void;
  onUpdateTargetPrice: (alertId: string, newTarget: number) => void;
  onSimulatePriceDrop: (alertId: string) => void;
  onSelectProductById: (productId: string) => void;
  onOpenCatalog: () => void;
}

export const PriceWatchModal: React.FC<PriceWatchModalProps> = ({
  alerts,
  onRemoveAlert,
  onUpdateTargetPrice,
  onSimulatePriceDrop,
  onSelectProductById,
  onOpenCatalog,
}) => {
  const [editingAlertId, setEditingAlertId] = useState<string | null>(null);
  const [newTargetInput, setNewTargetInput] = useState<string>('');

  const handleStartEdit = (alert: PriceAlert) => {
    setEditingAlertId(alert.id);
    setNewTargetInput(alert.targetPrice.toString());
  };

  const handleSaveEdit = (alertId: string) => {
    const val = parseFloat(newTargetInput);
    if (!isNaN(val) && val > 0) {
      onUpdateTargetPrice(alertId, val);
    }
    setEditingAlertId(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      
      {/* Header */}
      <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900">Autonomous Price Watchdog</h2>
            <span className="px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 text-[10px] font-bold border border-amber-200">
              {alerts.length} Active Tracks
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Aura monitors authorized seller inventories 24/7. When a price dips to or below your target threshold, we alert you instantly.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            Real-Time Monitoring Active
          </span>
        </div>
      </div>

      {/* Alerts List */}
      {alerts.length === 0 ? (
        <div className="text-center py-12 px-4 bg-white rounded-xl border border-slate-200 space-y-2 shadow-xs">
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-amber-500 mx-auto flex items-center justify-center">
            <Bell className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">No Active Price Watchers</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click the bell icon on any product in the catalog to set a custom target price threshold and let the AI agent track it.
          </p>
          <button
            onClick={onOpenCatalog}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium transition-all shadow-xs"
          >
            Explore Catalog
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {alerts.map((alert) => {
            const hasTriggered = alert.currentPrice <= alert.targetPrice;

            return (
              <div
                key={alert.id}
                className={`p-2.5 rounded-lg border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs ${
                  hasTriggered
                    ? 'bg-amber-50/80 border-amber-300'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Product Info */}
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={alert.productImage}
                    alt={alert.productTitle}
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded-lg object-cover bg-white shrink-0 cursor-pointer border border-slate-200"
                    onClick={() => onSelectProductById(alert.productId)}
                  />
                  <div className="min-w-0">
                    <h4
                      onClick={() => onSelectProductById(alert.productId)}
                      className="text-xs font-semibold text-slate-900 hover:text-emerald-700 cursor-pointer line-clamp-1 truncate"
                    >
                      {alert.productTitle}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                      <span>Current: <strong className="text-slate-900 font-bold">${alert.currentPrice.toFixed(2)}</strong></span>
                      <span>Target: <strong className="text-emerald-700 font-bold">${alert.targetPrice.toFixed(2)}</strong></span>
                    </div>

                    {hasTriggered && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 mt-0.5">
                        <Zap className="w-2.5 h-2.5 fill-current" />
                        Price Goal Met! (${(alert.currentPrice).toFixed(2)})
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-1.5 shrink-0">
                  
                  {/* Simulate Price Drop Button */}
                  <button
                    onClick={() => onSimulatePriceDrop(alert.id)}
                    title="Simulate retailer flash discount"
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-medium border border-indigo-200 transition-all flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-indigo-600" />
                    Simulate Price Drop
                  </button>

                  {/* Edit Target Price */}
                  {editingAlertId === alert.id ? (
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={newTargetInput}
                        onChange={(e) => setNewTargetInput(e.target.value)}
                        className="w-16 px-1.5 py-0.5 bg-white border border-slate-300 rounded text-xs text-slate-900"
                      />
                      <button
                        onClick={() => handleSaveEdit(alert.id)}
                        className="p-1 bg-slate-900 text-white rounded text-xs"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(alert)}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium border border-slate-200"
                    >
                      Edit Target
                    </button>
                  )}

                  {/* Remove alert */}
                  <button
                    onClick={() => onRemoveAlert(alert.id)}
                    className="p-1.5 bg-slate-100 hover:bg-rose-100 text-slate-500 hover:text-rose-700 rounded-lg transition-colors border border-slate-200"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
