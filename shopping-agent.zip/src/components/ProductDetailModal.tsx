import React, { useState } from 'react';
import { 
  X, 
  Star, 
  TrendingDown, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  Tag, 
  Copy, 
  Check, 
  ShoppingBag, 
  Bot, 
  Bell, 
  Scale, 
  Sparkles,
  Info,
  Truck
} from 'lucide-react';
import { Product, StorePrice, Coupon } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, store: StorePrice, coupon?: Coupon) => void;
  onToggleCompare: (product: Product) => void;
  isComparing: boolean;
  onSetPriceAlert: (product: Product) => void;
  isAlertSet: boolean;
  onAskAgentAboutProduct: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onToggleCompare,
  isComparing,
  onSetPriceAlert,
  isAlertSet,
  onAskAgentAboutProduct,
}) => {
  const [activeTab, setActiveTab] = useState<'matrix' | 'history' | 'reviews' | 'coupons' | 'specs'>('matrix');
  const [selectedStore, setSelectedStore] = useState<StorePrice | null>(null);
  const [copiedCoupon, setCopiedCoupon] = useState<string | null>(null);

  if (!product) return null;

  const currentSelectedStore = selectedStore || product.stores[0];
  const lowestStore = product.stores.reduce((prev, curr) => curr.price < prev.price ? curr : prev, product.stores[0]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCoupon(code);
    setTimeout(() => setCopiedCoupon(null), 2500);
  };

  // Price history calculations for SVG chart
  const minPrice = Math.min(...product.priceHistory.map(p => p.price));
  const maxPrice = Math.max(...product.priceHistory.map(p => p.price));
  const priceRange = maxPrice - minPrice || 1;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div 
        className="relative bg-white border border-slate-200 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-hidden shadow-xl flex flex-col text-slate-900"
        id="product-detail-modal"
      >
        {/* Modal Header */}
        <div className="p-3 sm:p-4 border-b border-slate-200 flex items-start justify-between gap-3 bg-white sticky top-0 z-10">
          <div className="space-y-0.5 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold uppercase tracking-wider">
                {product.brand}
              </span>
              <span className="text-[11px] text-slate-500">{product.category}</span>
              <div className="flex items-center gap-1 text-amber-500 text-[11px]">
                <Star className="w-3 h-3 fill-current" />
                <span className="font-bold text-slate-800">{product.rating}</span>
                <span className="text-slate-400">({product.reviewCount.toLocaleString()})</span>
              </div>
              <div className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-emerald-700">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>Fake Review Risk: {product.fakeReviewRisk || 'Low (Verified)'}</span>
              </div>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-snug truncate">
              {product.title}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
            id="btn-close-modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-3 sm:p-4 space-y-4 flex-1">
          
          {/* Top Hero Section: Image + Fast Purchase Summary */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Left: Product Image & Highlights */}
            <div className="md:col-span-5 space-y-2">
              <div className="aspect-[4/3] rounded-lg overflow-hidden bg-white border border-slate-200 relative">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute top-2 left-2 flex flex-col gap-1">
                  <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold shadow-xs">
                    AI Deal Score: {product.dealScore}/100
                  </span>
                  {product.dealLabel && (
                    <span className="px-1.5 py-0.2 rounded bg-amber-400 text-slate-900 text-[10px] font-bold shadow-xs">
                      {product.dealLabel}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons Toolbar */}
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => onAskAgentAboutProduct(product)}
                  className="py-1 px-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-800 flex items-center justify-center gap-1 transition-colors"
                >
                  <Bot className="w-3 h-3 text-emerald-700" />
                  Ask AI
                </button>
                <button
                  onClick={() => onToggleCompare(product)}
                  className={`py-1 px-2 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1 transition-colors ${
                    isComparing
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                      : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                  }`}
                >
                  <Scale className="w-3 h-3 text-indigo-600" />
                  {isComparing ? 'Comparing' : 'Compare'}
                </button>
                <button
                  onClick={() => onSetPriceAlert(product)}
                  className={`py-1 px-2 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1 transition-colors ${
                    isAlertSet
                      ? 'bg-amber-50 border-amber-300 text-amber-800'
                      : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                  }`}
                >
                  <Bell className="w-3 h-3 text-amber-500" />
                  {isAlertSet ? 'Tracking' : 'Alert'}
                </button>
              </div>
            </div>

            {/* Right: Pricing Box & AI Verdict */}
            <div className="md:col-span-7 space-y-2.5">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <div className="flex items-baseline justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Selected: {currentSelectedStore.storeName}</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-slate-900">
                        ${currentSelectedStore.price.toFixed(2)}
                      </span>
                      {product.originalPrice > currentSelectedStore.price && (
                        <span className="text-xs text-slate-400 line-through">
                          ${product.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="inline-block px-1.5 py-0.2 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                      {currentSelectedStore.inStock ? 'In Stock' : 'Backordered'}
                    </span>
                    <span className="block text-[10px] text-slate-500 mt-0.5 flex items-center justify-end gap-1">
                      <Truck className="w-2.5 h-2.5 text-slate-400" />
                      {currentSelectedStore.shipping}
                    </span>
                  </div>
                </div>

                {/* Direct Add To Cart Button */}
                <button
                  onClick={() => onAddToCart(product, currentSelectedStore)}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white rounded-lg font-medium text-xs transition-all shadow-xs flex items-center justify-center gap-1.5"
                  id="btn-modal-add-cart"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  Add to Cart (${currentSelectedStore.price.toFixed(2)} from {currentSelectedStore.storeName})
                </button>
              </div>

              {/* AI Agent Verdict Callout */}
              <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200 space-y-1">
                <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-800">
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  <span>Aura Shopper Intelligence Verdict</span>
                </div>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  {product.aiVerdict}
                </p>
              </div>

              {/* Quick Tags */}
              <div className="flex flex-wrap gap-1">
                {product.tags.map((tag, idx) => (
                  <span key={idx} className="px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 text-[10px]">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-200 gap-1 overflow-x-auto pb-1 text-xs font-medium">
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'matrix' ? 'bg-slate-900 text-white font-medium shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Multi-Store Price Matrix ({product.stores.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'history' ? 'bg-slate-900 text-white font-medium shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Price History & Trends
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'reviews' ? 'bg-slate-900 text-white font-medium shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              AI Review Synthesis
            </button>
            <button
              onClick={() => setActiveTab('coupons')}
              className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'coupons' ? 'bg-slate-900 text-white font-medium shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Verified Coupons ({product.coupons.length})
            </button>
            <button
              onClick={() => setActiveTab('specs')}
              className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'specs' ? 'bg-slate-900 text-white font-medium shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Specifications
            </button>
          </div>

          {/* TAB CONTENT */}

          {/* 1. Multi-Store Price Matrix */}
          {activeTab === 'matrix' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>Verified Retailers & In-Stock Condition</span>
                <span>Select store to buy or compare</span>
              </div>

              <div className="space-y-1.5">
                {product.stores.map((store, index) => {
                  const isCurrent = currentSelectedStore.storeName === store.storeName;
                  const isBest = store.price === lowestStore.price;

                  return (
                    <div
                      key={index}
                      onClick={() => setSelectedStore(store)}
                      className={`p-2 rounded-lg border transition-all flex items-center justify-between gap-3 cursor-pointer ${
                        isCurrent
                          ? 'bg-emerald-50/60 border-emerald-400 shadow-xs'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                          isCurrent ? 'border-emerald-600 bg-emerald-600/20' : 'border-slate-300'
                        }`}>
                          {isCurrent && <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />}
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-xs text-slate-900">{store.storeName}</span>
                            {isBest && (
                              <span className="px-1 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800">
                                Lowest
                              </span>
                            )}
                            <span className="text-[10px] text-slate-500 px-1 py-0.2 rounded bg-slate-100">
                              {store.condition}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.2">
                            <span>{store.shipping}</span> • <span className="text-amber-600">{store.rating} ★ rating</span>
                          </p>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-sm font-bold text-slate-900">${store.price.toFixed(2)}</span>
                          {store.originalPrice && store.originalPrice > store.price && (
                            <span className="block text-[10px] text-slate-400 line-through">${store.originalPrice.toFixed(2)}</span>
                          )}
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToCart(product, store);
                          }}
                          className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs"
                        >
                          Select
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 2. Price History Chart */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Historical Price Trajectory (6-Month Range)</h4>
                    <p className="text-[11px] text-slate-500">Tracked across primary authorized sellers</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-emerald-700 font-semibold block">Tracked Low: ${minPrice.toFixed(2)}</span>
                    <span className="text-[10px] text-slate-500">Peak: ${maxPrice.toFixed(2)}</span>
                  </div>
                </div>

                {/* SVG Visual Sparkline Chart */}
                <div className="h-36 w-full relative pt-2 pb-4">
                  <svg className="w-full h-full overflow-visible" viewBox="0 0 500 120" preserveAspectRatio="none">
                    <defs>
                      <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Grid lines */}
                    <line x1="0" y1="20" x2="500" y2="20" stroke="#e2e8f0" strokeDasharray="3 3" />
                    <line x1="0" y1="60" x2="500" y2="60" stroke="#e2e8f0" strokeDasharray="3 3" />
                    <line x1="0" y1="100" x2="500" y2="100" stroke="#e2e8f0" strokeDasharray="3 3" />

                    {/* Area Polygon */}
                    {(() => {
                      const points = product.priceHistory.map((pt, i) => {
                        const x = (i / (product.priceHistory.length - 1)) * 500;
                        const y = 100 - ((pt.price - minPrice) / priceRange) * 80;
                        return `${x},${y}`;
                      }).join(' ');

                      const firstX = 0;
                      const lastX = 500;
                      return (
                        <polygon
                          points={`${firstX},110 ${points} ${lastX},110`}
                          fill="url(#priceGradient)"
                        />
                      );
                    })()}

                    {/* Line path */}
                    {(() => {
                      const points = product.priceHistory.map((pt, i) => {
                        const x = (i / (product.priceHistory.length - 1)) * 500;
                        const y = 100 - ((pt.price - minPrice) / priceRange) * 80;
                        return `${x},${y}`;
                      }).join(' ');

                      return (
                        <polyline
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          points={points}
                        />
                      );
                    })()}

                    {/* Circles & Value Labels */}
                    {product.priceHistory.map((pt, i) => {
                      const x = (i / (product.priceHistory.length - 1)) * 500;
                      const y = 100 - ((pt.price - minPrice) / priceRange) * 80;
                      return (
                        <g key={i}>
                          <circle cx={x} cy={y} r="4" fill="#ffffff" stroke="#10b981" strokeWidth="2" />
                          <text
                            x={x}
                            y={y - 8}
                            textAnchor="middle"
                            fontSize="9"
                            fill="#0f172a"
                            fontWeight="bold"
                          >
                            ${pt.price.toFixed(0)}
                          </text>
                          <text
                            x={x}
                            y="116"
                            textAnchor="middle"
                            fontSize="8"
                            fill="#64748b"
                          >
                            {pt.date}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-slate-700 text-[11px]">Current price is near historical low. Great time to buy.</span>
                  </div>
                  <button
                    onClick={() => onSetPriceAlert(product)}
                    className="text-amber-700 hover:underline font-semibold text-xs"
                  >
                    Set price alert
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 3. AI Review Synthesis */}
          {activeTab === 'reviews' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Pros */}
                <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200 space-y-1.5">
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Verified Strengths</span>
                  </div>
                  <ul className="space-y-1">
                    {product.pros.map((pro, index) => (
                      <li key={index} className="text-xs text-slate-700 flex items-start gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cons */}
                <div className="p-3 rounded-lg bg-rose-50/70 border border-rose-200 space-y-1.5">
                  <div className="flex items-center gap-1 text-xs font-bold text-rose-800">
                    <XCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span>Reported Limitations</span>
                  </div>
                  <ul className="space-y-1">
                    {product.cons.map((con, index) => (
                      <li key={index} className="text-xs text-slate-700 flex items-start gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                        <span>{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Full Description */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <h4 className="text-xs font-bold text-slate-900">Product Overview</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {product.description}
                </p>
              </div>
            </div>
          )}

          {/* 4. Verified Coupons */}
          {activeTab === 'coupons' && (
            <div className="space-y-2">
              <div className="text-[11px] text-slate-500">
                Verified across official retailer checkout funnels:
              </div>

              {product.coupons.length === 0 ? (
                <div className="p-4 text-center text-slate-500 text-xs bg-slate-50 rounded-lg border border-slate-200">
                  No public promo codes currently available for this SKU. Instant markdowns are already reflected.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {product.coupons.map((coupon, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5 relative group">
                      <div className="flex items-center justify-between">
                        <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-xs font-mono font-bold tracking-wider">
                          {coupon.code}
                        </span>
                        <span className="text-[10px] text-emerald-700 font-semibold">
                          {coupon.successRate}% Success
                        </span>
                      </div>

                      <p className="text-xs text-slate-800">{coupon.discountDescription}</p>
                      
                      <div className="flex items-center justify-between pt-1 text-[10px] text-slate-500">
                        <span>Store: {coupon.store}</span>
                        <button
                          onClick={() => handleCopyCode(coupon.code)}
                          className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-semibold"
                        >
                          {copiedCoupon === coupon.code ? (
                            <>
                              <Check className="w-3 h-3" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              Copy & Apply
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 5. Technical Specifications */}
          {activeTab === 'specs' && (
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-xs text-left">
                <tbody>
                  {Object.entries(product.specs).map(([key, value], idx) => (
                    <tr key={idx} className={idx % 2 === 0 ? 'bg-slate-50/60' : 'bg-white'}>
                      <td className="px-3 py-1.5 font-semibold text-slate-600 w-1/3 border-b border-slate-200">
                        {key}
                      </td>
                      <td className="px-3 py-1.5 text-slate-800 border-b border-slate-200">
                        {value}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
