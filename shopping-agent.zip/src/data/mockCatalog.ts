import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-sony-wh1000xm5',
    title: 'Sony WH-1000XM5 Wireless Noise-Canceling Headphones',
    brand: 'Sony',
    category: 'Audio & Wearables',
    rating: 4.8,
    reviewCount: 3840,
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    currentPrice: 328.00,
    originalPrice: 399.99,
    dealScore: 94,
    dealLabel: 'Lowest in 90 Days',
    stores: [
      {
        storeName: 'Amazon',
        price: 328.00,
        originalPrice: 399.99,
        inStock: true,
        shipping: 'Free Next-Day Prime',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Best Buy',
        price: 349.99,
        originalPrice: 399.99,
        inStock: true,
        shipping: 'Free Store Pickup Today',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
      },
      {
        storeName: 'B&H Photo',
        price: 338.00,
        originalPrice: 399.99,
        inStock: true,
        shipping: 'Free Expedited Shipping',
        url: 'https://bhphotovideo.com',
        condition: 'New',
        rating: 4.9,
      },
      {
        storeName: 'Walmart',
        price: 358.50,
        originalPrice: 399.99,
        inStock: true,
        shipping: 'Free 2-day Shipping',
        url: 'https://walmart.com',
        condition: 'New',
        rating: 4.7,
      },
      {
        storeName: 'eBay',
        price: 269.00,
        originalPrice: 399.99,
        inStock: true,
        shipping: 'Free Standard',
        url: 'https://ebay.com',
        condition: 'Refurbished (Excellent)',
        rating: 4.6,
      }
    ],
    description: 'Industry-leading noise canceling with two processors and 8 microphones. Magnificent sound quality with 30mm precision-engineered drivers and LDAC support.',
    specs: {
      'Battery Life': 'Up to 30 hours (ANC on)',
      'Noise Cancellation': 'Dual Processor V1 + HD QN1',
      'Weight': '250g (8.8 oz)',
      'Connectivity': 'Bluetooth 5.2, Multipoint, 3.5mm jack',
      'Fast Charge': '3 min charge gives 3 hours playback'
    },
    pros: [
      'Top-tier active noise cancellation in class',
      'Extremely comfortable, lightweight redesigned headband',
      'Exceptional call quality with beamforming mics & AI reduction',
      'Crisp, balanced sound profile with custom EQ'
    ],
    cons: [
      'Does not fold completely flat like previous XM4',
      'Touch controls can be sensitive in rain'
    ],
    aiVerdict: 'Top recommendation for travelers, commuters, and focus workers. Amazon currently beats Best Buy by $21.99, making this an optimal buy point.',
    priceHistory: [
      { date: '6 Mos Ago', price: 399.99 },
      { date: '4 Mos Ago', price: 379.00 },
      { date: '2 Mos Ago', price: 348.00 },
      { date: 'Last Month', price: 389.99 },
      { date: 'Today', price: 328.00 }
    ],
    coupons: [
      {
        code: 'SONYTECH15',
        discountDescription: 'Extra $15 off on select premium audio',
        discountAmount: 15,
        discountType: 'fixed',
        store: 'Amazon',
        successRate: 94,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Noise Canceling', 'Wireless', 'Audiophile', 'Travel', 'Best Seller'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-macbook-air-m3',
    title: 'Apple MacBook Air 13-inch (M3 Chip, 16GB RAM, 512GB SSD)',
    brand: 'Apple',
    category: 'Electronics',
    rating: 4.9,
    reviewCount: 2190,
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
    currentPrice: 1249.00,
    originalPrice: 1399.00,
    dealScore: 91,
    dealLabel: '$150 Instant Off',
    stores: [
      {
        storeName: 'B&H Photo',
        price: 1249.00,
        originalPrice: 1399.00,
        inStock: true,
        shipping: 'Free 1-Day Air (select regions)',
        url: 'https://bhphotovideo.com',
        condition: 'New',
        rating: 4.9,
        isLowest: true,
      },
      {
        storeName: 'Amazon',
        price: 1269.99,
        originalPrice: 1399.00,
        inStock: true,
        shipping: 'Free Prime 2-Day',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.9,
      },
      {
        storeName: 'Best Buy',
        price: 1299.00,
        originalPrice: 1399.00,
        inStock: true,
        shipping: 'Free Delivery',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
      },
      {
        storeName: 'Apple',
        price: 1399.00,
        originalPrice: 1399.00,
        inStock: true,
        shipping: 'Free Standard Apple Delivery',
        url: 'https://apple.com',
        condition: 'New',
        rating: 5.0,
      }
    ],
    description: 'Incredible portability combined with the ultra-fast M3 chip. Dual external display support with lid closed, Liquid Retina display, and up to 18 hours battery life.',
    specs: {
      'Chip': 'Apple M3 (8-core CPU, 10-core GPU)',
      'Memory': '16GB Unified Memory',
      'Storage': '512GB Fast NVMe SSD',
      'Display': '13.6" Liquid Retina (2560 x 1664), 500 nits',
      'Battery': 'Up to 18 hours',
      'Weight': '2.7 lbs (1.24 kg)'
    },
    pros: [
      'Blazing fast single & multi-core performance with zero fan noise',
      'Battery easily lasts 1.5 workdays on single charge',
      'Vibrant True Tone display and crisp 1080p FaceTime HD camera',
      'Supports two external monitors (with clamshell mode)'
    ],
    cons: [
      'Midnight color shows fingerprints easily',
      'Only 2 Thunderbolt ports on the left side'
    ],
    aiVerdict: 'B&H offers the best deal with an additional $20 advantage over Amazon. The 16GB RAM tier ensures 5+ years of future-proofing.',
    priceHistory: [
      { date: '6 Mos Ago', price: 1399.00 },
      { date: '4 Mos Ago', price: 1349.00 },
      { date: '2 Mos Ago', price: 1299.00 },
      { date: 'Last Month', price: 1299.00 },
      { date: 'Today', price: 1249.00 }
    ],
    coupons: [
      {
        code: 'MACBOOST25',
        discountDescription: '$25 off on select Mac configurations',
        discountAmount: 25,
        discountType: 'fixed',
        store: 'B&H Photo',
        successRate: 88,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Laptop', 'Apple Silicon', 'Ultraportable', 'Productivity', 'Student'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-logitech-mx-master-3s',
    title: 'Logitech MX Master 3S Performance Wireless Mouse',
    brand: 'Logitech',
    category: 'Electronics',
    rating: 4.8,
    reviewCount: 9410,
    imageUrl: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=800&q=80',
    currentPrice: 84.99,
    originalPrice: 99.99,
    dealScore: 89,
    dealLabel: '15% Off Sale',
    stores: [
      {
        storeName: 'Amazon',
        price: 84.99,
        originalPrice: 99.99,
        inStock: true,
        shipping: 'Free One-Day Prime',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Best Buy',
        price: 89.99,
        originalPrice: 99.99,
        inStock: true,
        shipping: 'Free Store Pickup',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
      },
      {
        storeName: 'Target',
        price: 94.99,
        originalPrice: 99.99,
        inStock: true,
        shipping: 'Free with RedCard',
        url: 'https://target.com',
        condition: 'New',
        rating: 4.7,
      }
    ],
    description: 'An iconic ergonomic mouse remastered with 8,000 DPI track-on-glass sensor and 90% quieter clicks for seamless multitasking across up to 3 computers.',
    specs: {
      'Sensor': '8,000 DPI Darkfield sensor (tracks on glass)',
      'Scroll Wheel': 'MagSpeed electromagnetic hyper-fast scrolling',
      'Battery Life': '70 days on full charge (USB-C)',
      'Compatibility': 'Windows, macOS, iPadOS, Linux, ChromeOS',
      'Customization': 'Logi Options+ multi-app gestures'
    },
    pros: [
      'MagSpeed scroll wheel scrolls 1,000 lines per second silently',
      'Ergonomic thumb cradle with horizontal scroll wheel',
      'Works seamlessly across multiple screens with Logitech Flow'
    ],
    cons: [
      'Optimized primarily for right-handed users',
      'Slightly heavier than minimalist travel mice (141g)'
    ],
    aiVerdict: 'Unmatched gold standard for productivity and design workflows. Amazon is currently lowest with instant delivery.',
    priceHistory: [
      { date: '6 Mos Ago', price: 99.99 },
      { date: '4 Mos Ago', price: 94.99 },
      { date: '2 Mos Ago', price: 99.99 },
      { date: 'Last Month', price: 89.99 },
      { date: 'Today', price: 84.99 }
    ],
    coupons: [
      {
        code: 'PERIPH5',
        discountDescription: '5% off computer accessories',
        discountAmount: 5,
        discountType: 'percentage',
        store: 'Amazon',
        successRate: 91,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Ergonomic', 'Productivity', 'Office', 'Bluetooth', 'Best Seller'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-dyson-v15-detect',
    title: 'Dyson V15 Detect Cordless Vacuum Cleaner',
    brand: 'Dyson',
    category: 'Home & Living',
    rating: 4.7,
    reviewCount: 4120,
    imageUrl: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?auto=format&fit=crop&w=800&q=80',
    currentPrice: 589.00,
    originalPrice: 749.99,
    dealScore: 96,
    dealLabel: 'Save $160 (Record Low)',
    stores: [
      {
        storeName: 'Target',
        price: 589.00,
        originalPrice: 749.99,
        inStock: true,
        shipping: 'Free 2-Day Shipping',
        url: 'https://target.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Amazon',
        price: 599.99,
        originalPrice: 749.99,
        inStock: true,
        shipping: 'Free Prime Shipping',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.7,
      },
      {
        storeName: 'Best Buy',
        price: 619.99,
        originalPrice: 749.99,
        inStock: true,
        shipping: 'Free Delivery',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.7,
      },
      {
        storeName: 'Direct Store',
        price: 649.99,
        originalPrice: 749.99,
        inStock: true,
        shipping: 'Free Dyson direct tools kit',
        url: 'https://dyson.com',
        condition: 'New',
        rating: 4.9,
      }
    ],
    description: 'Dyson’s most powerful intelligent cordless vacuum. Features green laser illumination to reveal invisible dust, piezo sensor particle count, and anti-tangle hair screw tool.',
    specs: {
      'Suction Power': '230 Air Watts',
      'Run Time': 'Up to 60 minutes',
      'Filtration': 'Whole-machine HEPA captures 99.99% particles to 0.3 microns',
      'Bin Volume': '0.20 Gallons (0.77L)',
      'Weight': '6.8 lbs (3.1 kg)'
    },
    pros: [
      'Fluffy Optic cleaner head makes fine dust shockingly visible',
      'Automatically adjusts suction power based on floor type and dirt density',
      'Digital Motorbar deep cleans carpets without hair tangling'
    ],
    cons: [
      'Trigger needs to be held down during cleaning',
      'High price point when not on sale'
    ],
    aiVerdict: 'Target has triggered a flash price-match down to $589 ($160 below retail). Highly recommended buy window before promo expires.',
    priceHistory: [
      { date: '6 Mos Ago', price: 749.99 },
      { date: '4 Mos Ago', price: 699.99 },
      { date: '2 Mos Ago', price: 649.00 },
      { date: 'Last Month', price: 749.99 },
      { date: 'Today', price: 589.00 }
    ],
    coupons: [
      {
        code: 'HOMECARE10',
        discountDescription: '10% off select home appliances',
        discountAmount: 10,
        discountType: 'percentage',
        store: 'Target',
        successRate: 86,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Vacuum', 'Smart Home', 'Cleaning', 'Pet Friendly', 'HEPA'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-breville-barista-express',
    title: 'Breville Barista Express Espresso Machine (BES870XL)',
    brand: 'Breville',
    category: 'Kitchen',
    rating: 4.8,
    reviewCount: 14200,
    imageUrl: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?auto=format&fit=crop&w=800&q=80',
    currentPrice: 559.95,
    originalPrice: 699.95,
    dealScore: 92,
    dealLabel: '20% Holiday Discount',
    stores: [
      {
        storeName: 'Amazon',
        price: 559.95,
        originalPrice: 699.95,
        inStock: true,
        shipping: 'Free Prime Delivery',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Best Buy',
        price: 559.95,
        originalPrice: 699.95,
        inStock: true,
        shipping: 'Free Store Pickup',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Target',
        price: 599.95,
        originalPrice: 699.95,
        inStock: true,
        shipping: 'Free Standard',
        url: 'https://target.com',
        condition: 'New',
        rating: 4.7,
      },
      {
        storeName: 'eBay',
        price: 439.00,
        originalPrice: 699.95,
        inStock: true,
        shipping: 'Free Shipping',
        url: 'https://ebay.com',
        condition: 'Refurbished (Excellent)',
        rating: 4.7,
      }
    ],
    description: 'Create third wave specialty coffee at home from bean to espresso in under a minute. Integrated conical burr grinder, precise digital PID temperature control, and microfoam steam wand.',
    specs: {
      'Heating System': '1600W Thermocoil system with PID temp control',
      'Grinder': 'Integrated stainless steel conical burr grinder (1/2 lb hopper)',
      'Pump Pressure': '15 Bar Italian pump with low pressure pre-infusion',
      'Water Tank': '67 fl oz (2L) removable with charcoal water filter',
      'Dimensions': '12" x 11" x 13.5"'
    },
    pros: [
      'All-in-one setup saves counter space by combining grinder and espresso machine',
      'Pressure gauge teaches proper extraction technique intuitively',
      'Manual microfoam steam wand allows real latte art creation'
    ],
    cons: [
      'Requires a slight learning curve to dial in beans properly',
      'Drip tray needs frequent emptying during cleaning cycles'
    ],
    aiVerdict: 'The quintessential home cafe gateway. Amazon and Best Buy are tied at the lowest price point of $559.95. Applying coupon drops it further.',
    priceHistory: [
      { date: '6 Mos Ago', price: 699.95 },
      { date: '4 Mos Ago', price: 649.95 },
      { date: '2 Mos Ago', price: 599.95 },
      { date: 'Last Month', price: 699.95 },
      { date: 'Today', price: 559.95 }
    ],
    coupons: [
      {
        code: 'BREVILLEDISCOUNT20',
        discountDescription: 'Extra $20 off countertop kitchen appliances',
        discountAmount: 20,
        discountType: 'fixed',
        store: 'Amazon',
        successRate: 90,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Espresso', 'Coffee Maker', 'Kitchen', 'Barista', 'Gourmet'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-kindle-paperwhite-signature',
    title: 'Kindle Paperwhite Signature Edition (32 GB, Wireless Charging, Auto-Adjusting Light)',
    brand: 'Amazon',
    category: 'Electronics',
    rating: 4.8,
    reviewCount: 16800,
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80',
    currentPrice: 144.99,
    originalPrice: 189.99,
    dealScore: 93,
    dealLabel: '24% Off Prime Price',
    stores: [
      {
        storeName: 'Amazon',
        price: 144.99,
        originalPrice: 189.99,
        inStock: true,
        shipping: 'Free Same-Day / One-Day',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.9,
        isLowest: true,
      },
      {
        storeName: 'Best Buy',
        price: 159.99,
        originalPrice: 189.99,
        inStock: true,
        shipping: 'Free Store Pickup',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
      },
      {
        storeName: 'Target',
        price: 164.99,
        originalPrice: 189.99,
        inStock: true,
        shipping: 'Free Delivery',
        url: 'https://target.com',
        condition: 'New',
        rating: 4.7,
      }
    ],
    description: 'Get everything in the Kindle Paperwhite, plus wireless charging, auto-adjusting front light, 32 GB storage, and no lockscreen ads.',
    specs: {
      'Display': '6.8" Paperwhite display with 300 ppi glare-free screen',
      'Battery Life': 'Up to 10 weeks on single charge',
      'Waterproof': 'IPX8 waterproof rating (tested in 2 meters of fresh water)',
      'Storage': '32 GB holds thousands of audiobooks & books',
      'Lighting': '17 LEDs with adjustable warm light'
    },
    pros: [
      'Warm light adjustment eliminates blue light for nighttime reading',
      'Immense battery life measured in months, not hours',
      'Waterproof design safe for bathtub or pool'
    ],
    cons: [
      'Color e-ink not supported (monochrome display)',
      'Wireless charging dock sold separately'
    ],
    aiVerdict: 'Outstanding value for avid bookworms. The Signature Edition adds Qi wireless charging and 4x storage for a modest price premium.',
    priceHistory: [
      { date: '6 Mos Ago', price: 189.99 },
      { date: '4 Mos Ago', price: 169.99 },
      { date: '2 Mos Ago', price: 189.99 },
      { date: 'Last Month', price: 174.99 },
      { date: 'Today', price: 144.99 }
    ],
    coupons: [
      {
        code: 'READMORE10',
        discountDescription: '$10 credit towards Kindle ebook store with device',
        discountAmount: 10,
        discountType: 'fixed',
        store: 'Amazon',
        successRate: 98,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['E-Reader', 'Books', 'Waterproof', 'Signature', 'Amazon'],
    isStaffPick: false,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-nike-air-zoom-pegasus-41',
    title: 'Nike Pegasus 41 Road Running Shoes',
    brand: 'Nike',
    category: 'Fashion & Apparel',
    rating: 4.7,
    reviewCount: 2450,
    imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
    currentPrice: 109.97,
    originalPrice: 140.00,
    dealScore: 88,
    dealLabel: '21% Nike Member Markdown',
    stores: [
      {
        storeName: 'Nike',
        price: 109.97,
        originalPrice: 140.00,
        inStock: true,
        shipping: 'Free Nike Member Shipping',
        url: 'https://nike.com',
        condition: 'New',
        rating: 4.8,
        isLowest: true,
      },
      {
        storeName: 'Amazon',
        price: 124.95,
        originalPrice: 140.00,
        inStock: true,
        shipping: 'Free Prime Shipping',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.6,
      },
      {
        storeName: 'Direct Store',
        price: 119.99,
        originalPrice: 140.00,
        inStock: true,
        shipping: 'Standard $5.00',
        url: 'https://dickssportinggoods.com',
        condition: 'New',
        rating: 4.7,
      }
    ],
    description: 'Responsive cushioning in the Pegasus delivers an energized ride for everyday road running. Upgraded with ReactX foam midsole and dual Air Zoom units.',
    specs: {
      'Midsole': 'ReactX foam (13% more responsive, lower carbon footprint)',
      'Air Units': 'Forefoot and heel Air Zoom units',
      'Weight': 'Approx. 297g / 10.4 oz (Men’s 10)',
      'Drop': '10 mm (37mm heel / 27mm forefoot)',
      'Upper': 'Engineered mesh with plush collar'
    },
    pros: [
      'Versatile daily workhorse capable of slow recovery runs and tempo paces',
      'ReactX foam provides noticeable energy return without bottoming out',
      'Durable waffle-pattern rubber outsole provides dependable wet grip'
    ],
    cons: [
      'Toe box fits slightly snug for runners with wide feet',
      'Not a featherweight carbon-plated race day shoe'
    ],
    aiVerdict: 'Buying direct from Nike.com with the MEMBER20 code unlocks the steepest discount seen this quarter.',
    priceHistory: [
      { date: '6 Mos Ago', price: 140.00 },
      { date: '4 Mos Ago', price: 140.00 },
      { date: '2 Mos Ago', price: 129.99 },
      { date: 'Last Month', price: 124.95 },
      { date: 'Today', price: 109.97 }
    ],
    coupons: [
      {
        code: 'SPORTSTYLE15',
        discountDescription: 'Extra 15% off clearance footwear',
        discountAmount: 15,
        discountType: 'percentage',
        store: 'Nike',
        successRate: 95,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Running', 'Footwear', 'Sneakers', 'Fitness', 'Athletic'],
    isStaffPick: false,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-patagonia-torrentshell-3l',
    title: 'Patagonia Torrentshell 3L Waterproof Rain Jacket',
    brand: 'Patagonia',
    category: 'Fitness & Outdoors',
    rating: 4.9,
    reviewCount: 3100,
    imageUrl: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=800&q=80',
    currentPrice: 139.30,
    originalPrice: 179.00,
    dealScore: 90,
    dealLabel: '22% Seasonal Markdown',
    stores: [
      {
        storeName: 'Direct Store',
        price: 139.30,
        originalPrice: 179.00,
        inStock: true,
        shipping: 'Free Shipping over $99',
        url: 'https://rei.com',
        condition: 'New',
        rating: 4.9,
        isLowest: true,
      },
      {
        storeName: 'Amazon',
        price: 159.00,
        originalPrice: 179.00,
        inStock: true,
        shipping: 'Free 2-day Prime',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.7,
      },
      {
        storeName: 'eBay',
        price: 115.00,
        originalPrice: 179.00,
        inStock: true,
        shipping: '$6.50 shipping',
        url: 'https://ebay.com',
        condition: 'Refurbished (Excellent)',
        rating: 4.8,
      }
    ],
    description: 'Simple and unpretentious, Patagonia’s trusted Torrentshell 3L Jacket uses 3-layer H2No Performance Standard technology and a PFC-free DWR finish for exceptional waterproof/breathable performance.',
    specs: {
      'Material': '3-layer 100% recycled nylon ripstop',
      'Membrane': 'H2No Performance Standard waterproof barrier',
      'Weight': '394g (13.9 oz)',
      'Features': 'Microfleece-lined neck, pit zips, self-stuffs into pocket',
      'Sustainability': 'Fair Trade Certified sewn, PFC-free DWR'
    },
    pros: [
      'Bulletproof waterproofing that withstands torrential downpours',
      'Two-way pit zips offer essential ventilation when hiking uphill',
      'Ironclad Patagonia lifetime warranty and repair program'
    ],
    cons: [
      'Crisp 3L fabric produces slight crinkling sound when moving',
      'No chest pocket on standard model'
    ],
    aiVerdict: 'REI currently leads pricing on Patagonia clearance colors. Durable 3-layer shell will outlast cheaper 2.5-layer alternatives by years.',
    priceHistory: [
      { date: '6 Mos Ago', price: 179.00 },
      { date: '4 Mos Ago', price: 179.00 },
      { date: '2 Mos Ago', price: 159.00 },
      { date: 'Last Month', price: 179.00 },
      { date: 'Today', price: 139.30 }
    ],
    coupons: [
      {
        code: 'OUTDOORS10',
        discountDescription: '10% off member reward on gear',
        discountAmount: 10,
        discountType: 'percentage',
        store: 'Direct Store',
        successRate: 89,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Rain Jacket', 'Waterproof', 'Hiking', 'Patagonia', 'Eco-Friendly'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  },
  {
    id: 'prod-anker-737-power-bank',
    title: 'Anker 737 Power Bank (PowerCore 24K, 140W Two-Way Fast Charge)',
    brand: 'Anker',
    category: 'Electronics',
    rating: 4.8,
    reviewCount: 7850,
    imageUrl: 'https://images.unsplash.com/photo-1609592424385-e653063fdb2c?auto=format&fit=crop&w=800&q=80',
    currentPrice: 99.99,
    originalPrice: 149.99,
    dealScore: 95,
    dealLabel: 'Save $50 (33% OFF)',
    stores: [
      {
        storeName: 'Amazon',
        price: 99.99,
        originalPrice: 149.99,
        inStock: true,
        shipping: 'Free Prime Overnight',
        url: 'https://amazon.com',
        condition: 'New',
        rating: 4.9,
        isLowest: true,
      },
      {
        storeName: 'Best Buy',
        price: 119.99,
        originalPrice: 149.99,
        inStock: true,
        shipping: 'Free Shipping',
        url: 'https://bestbuy.com',
        condition: 'New',
        rating: 4.8,
      },
      {
        storeName: 'Newegg',
        price: 109.99,
        originalPrice: 149.99,
        inStock: true,
        shipping: 'Free 3-Day',
        url: 'https://newegg.com',
        condition: 'New',
        rating: 4.7,
      }
    ],
    description: 'Equipped with Power Delivery 3.1 and bi-directional charging to quickly juice up the charger or get a 140W ultra-powerful charge for MacBook Pros, phones, and tablets.',
    specs: {
      'Capacity': '24,000mAh (86.4Wh - TSA carry-on approved)',
      'Max Output': '140W single port (USB-C Power Delivery 3.1)',
      'Display': 'Smart digital color display showing real-time wattage & recharge time',
      'Ports': '2x USB-C + 1x USB-A (charge 3 devices at once)',
      'Weight': '1.39 lbs (630g)'
    },
    pros: [
      'Can charge a 16-inch MacBook Pro from 0 to 50% in just 28 minutes',
      'Detailed screen shows exact battery health, cycle count, and temperature',
      'Recharges itself from 0 to 100% in under 52 minutes with 140W wall plug'
    ],
    cons: [
      'Dense brick-like form factor not suitable for pocket carry',
      'Requires high wattage 100W+ cable and brick to unlock full speed'
    ],
    aiVerdict: 'Steep $50 price drop on Amazon makes this the highest value high-output portable battery for travelers and digital nomads.',
    priceHistory: [
      { date: '6 Mos Ago', price: 149.99 },
      { date: '4 Mos Ago', price: 129.99 },
      { date: '2 Mos Ago', price: 119.99 },
      { date: 'Last Month', price: 139.99 },
      { date: 'Today', price: 99.99 }
    ],
    coupons: [
      {
        code: 'ANKERPOWER10',
        discountDescription: '$10 clip coupon at checkout',
        discountAmount: 10,
        discountType: 'fixed',
        store: 'Amazon',
        successRate: 97,
        verifiedDate: 'Verified today'
      }
    ],
    tags: ['Power Bank', 'Fast Charging', 'MacBook', 'Travel Gear', 'USB-C'],
    isStaffPick: true,
    fakeReviewRisk: 'Low (Verified)'
  }
];
