import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  ShoppingBag, 
  Scale, 
  Package, 
  Bell, 
  Receipt, 
  Search, 
  Sparkles, 
  SlidersHorizontal, 
  Tag, 
  TrendingDown, 
  Filter, 
  Check, 
  Loader2, 
  Zap,
  ArrowRight,
  ShieldCheck,
  Star,
  ExternalLink
} from 'lucide-react';

import { Product, StorePrice, CartItem, PriceAlert, Order, ViewMode, AgentMessage, Coupon } from './types';
import { INITIAL_PRODUCTS } from './data/mockCatalog';

import { Navbar } from './components/Navbar';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AgentChat } from './components/AgentChat';
import { PriceComparisonView } from './components/PriceComparisonView';
import { KitBuilder } from './components/KitBuilder';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { PriceWatchModal } from './components/PriceWatchModal';
import { VisualSearchModal } from './components/VisualSearchModal';
import { OrderHistoryModal } from './components/OrderHistoryModal';

export default function App() {
  // Main Products Catalog (Baseline + Dynamic AI Discovered Products)
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [currentView, setCurrentView] = useState<ViewMode>('catalog');

  // Search and Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStore, setSelectedStore] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'deal_score' | 'price_low' | 'price_high' | 'rating'>('deal_score');
  const [minDealScore, setMinDealScore] = useState<number>(0);
  const [isSearchingLive, setIsSearchingLive] = useState<boolean>(false);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: INITIAL_PRODUCTS[0], // Sony XM5
      selectedStore: INITIAL_PRODUCTS[0].stores[0],
      quantity: 1,
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [appliedCheckoutDiscount, setAppliedCheckoutDiscount] = useState(0);

  // Comparison State (up to 4 products)
  const [compareList, setCompareList] = useState<Product[]>([
    INITIAL_PRODUCTS[0],
    INITIAL_PRODUCTS[1]
  ]);

  // Price Alerts State
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([
    {
      id: 'alert-1',
      productId: INITIAL_PRODUCTS[0].id,
      productTitle: INITIAL_PRODUCTS[0].title,
      productImage: INITIAL_PRODUCTS[0].imageUrl,
      currentPrice: INITIAL_PRODUCTS[0].currentPrice,
      originalPrice: INITIAL_PRODUCTS[0].originalPrice,
      targetPrice: 299.00,
      createdAt: 'Aug 2026',
      active: true,
    },
    {
      id: 'alert-2',
      productId: INITIAL_PRODUCTS[3].id, // Dyson V15
      productTitle: INITIAL_PRODUCTS[3].title,
      productImage: INITIAL_PRODUCTS[3].imageUrl,
      currentPrice: INITIAL_PRODUCTS[3].currentPrice,
      originalPrice: INITIAL_PRODUCTS[3].originalPrice,
      targetPrice: 550.00,
      createdAt: 'Aug 2026',
      active: true,
    }
  ]);

  // Orders State
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD-892144',
      date: 'Aug 20, 2026',
      items: [
        {
          productTitle: 'Logitech MX Master 3S Wireless Mouse',
          productImage: INITIAL_PRODUCTS[2].imageUrl,
          storeName: 'Amazon',
          price: 84.99,
          quantity: 1
        }
      ],
      totalSavings: 15.00,
      totalAmount: 91.36,
      shippingAddress: '742 Evergreen Terrace, San Francisco, CA 94107',
      status: 'Delivered',
      agentNotes: 'Auto-applied 15% coupon at Amazon checkout.',
      trackingNumber: 'TRK-AURA-84729103'
    }
  ]);

  // Modals & Inspection State
  const [selectedProductDetail, setSelectedProductDetail] = useState<Product | null>(null);
  const [isVisualSearchOpen, setIsVisualSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; type: 'success' | 'alert' } | null>(null);

  // Agent Chat Conversation State
  const [chatMessages, setChatMessages] = useState<AgentMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'agent',
      timestamp: 'Just now',
      text: `Hello! I'm **Aura AI Shopping Agent**, your personal shopper and multi-store deal concierge.

I monitor real-time pricing across Amazon, Best Buy, Walmart, Target, B&H, Nike, and more. Here is what I can do for you:
• 🔍 **Product Discovery & Deep Search**: Find exact specs, deals, and alternatives.
• ⚖️ **Objective Showdowns**: Compare models, spec differences, and pros/cons.
• 🏷️ **Coupon & Price Tracking**: Test active promo codes and alert you to price drops.
• 📦 **Curated Kit Builder**: Assemble full setups within your exact budget.

How can I help you shop today?`,
      suggestedActions: [
        { type: 'search', label: 'Find best noise-canceling headphones under $350' },
        { type: 'compare', label: 'Compare Sony WH-1000XM5 vs MacBook Air M3' },
        { type: 'build_kit', label: 'Build a desk setup for $600' },
      ],
    }
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Show toast helper
  const triggerToast = (title: string, desc: string, type: 'success' | 'alert' = 'success') => {
    setToastMessage({ title, desc, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Cart Calculations
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.selectedStore.price * item.quantity, 0);

  // Filter Categories
  const CATEGORIES = ['All', 'Electronics', 'Audio & Wearables', 'Home & Living', 'Kitchen', 'Fashion & Apparel', 'Fitness & Outdoors'];
  const STORES = ['All', 'Amazon', 'Best Buy', 'Target', 'Walmart', 'B&H Photo', 'Nike', 'Direct Store'];

  // Handle Cart Operations
  const handleAddToCart = (product: Product, store: StorePrice, coupon?: Coupon) => {
    setCart((prev) => {
      const existing = prev.find(
        (item) => item.product.id === product.id && item.selectedStore.storeName === store.storeName
      );
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.selectedStore.storeName === store.storeName
            ? { ...item, quantity: item.quantity + 1, appliedCoupon: coupon || item.appliedCoupon }
            : item
        );
      }
      return [...prev, { product, selectedStore: store, quantity: 1, appliedCoupon: coupon }];
    });

    triggerToast('Added to Universal Cart', `${product.title} from ${store.storeName} ($${store.price.toFixed(2)})`);
  };

  const handleAddMultipleToCart = (items: { product: Product; store: StorePrice }[]) => {
    items.forEach(item => {
      handleAddToCart(item.product, item.store);
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, storeName: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId && item.selectedStore.storeName === storeName) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string, storeName: string) => {
    setCart((prev) =>
      prev.filter(
        (item) => !(item.product.id === productId && item.selectedStore.storeName === storeName)
      )
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Compare Operations
  const handleToggleCompare = (product: Product) => {
    setCompareList((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= 4) {
        triggerToast('Comparison Limit Reached', 'You can compare up to 4 items simultaneously.', 'alert');
        return prev;
      }
      triggerToast('Added to Showdown', `${product.title} added to comparison tray.`);
      return [...prev, product];
    });
  };

  // Price Alert Operations
  const handleSetPriceAlert = (product: Product) => {
    const existing = priceAlerts.find((a) => a.productId === product.id);
    if (existing) {
      triggerToast('Already Tracking', `You are already watching price drops for ${product.title}`);
      setCurrentView('alerts');
      return;
    }

    const defaultTarget = Math.round(product.currentPrice * 0.85); // 15% drop target
    const newAlert: PriceAlert = {
      id: `alert-${Date.now()}`,
      productId: product.id,
      productTitle: product.title,
      productImage: product.imageUrl,
      currentPrice: product.currentPrice,
      originalPrice: product.originalPrice,
      targetPrice: defaultTarget,
      createdAt: 'Just now',
      active: true,
    };

    setPriceAlerts((prev) => [newAlert, ...prev]);
    triggerToast('Price Watchdog Activated', `We will alert you when ${product.title} drops to $${defaultTarget}`);
  };

  const handleRemovePriceAlert = (alertId: string) => {
    setPriceAlerts((prev) => prev.filter((a) => a.id !== alertId));
  };

  const handleUpdateTargetPrice = (alertId: string, newTarget: number) => {
    setPriceAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, targetPrice: newTarget } : a))
    );
    triggerToast('Target Updated', `New price threshold set to $${newTarget}`);
  };

  // Simulate price drop (engaging test trigger)
  const handleSimulatePriceDrop = (alertId: string) => {
    setPriceAlerts((prev) =>
      prev.map((a) => {
        if (a.id === alertId) {
          const droppedPrice = a.targetPrice - 10;
          
          // Also update the product in products state
          setProducts((prodList) =>
            prodList.map((p) =>
              p.id === a.productId
                ? {
                    ...p,
                    currentPrice: droppedPrice,
                    dealScore: 98,
                    dealLabel: 'FLASH PRICE DROP TRIGGERED',
                    stores: p.stores.map((s, idx) =>
                      idx === 0 ? { ...s, price: droppedPrice, isLowest: true } : s
                    ),
                  }
                : p
            )
          );

          triggerToast(
            '🔥 PRICE DROP ALERT!',
            `Flash deal on ${a.productTitle}! Dropped to $${droppedPrice.toFixed(2)} (Below your target $${a.targetPrice.toFixed(2)})`,
            'alert'
          );

          return { ...a, currentPrice: droppedPrice, notified: true };
        }
        return a;
      })
    );
  };

  // Order Placement
  const handleOrderPlaced = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    setCart([]);
    setIsCheckoutOpen(false);
    triggerToast('Order Successfully Placed', `Order #${order.id} confirmed with $${order.totalSavings.toFixed(2)} total savings!`);
  };

  // Agent Chat Message Handler
  const handleSendMessage = async (text: string) => {
    const userMessage: AgentMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text,
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setIsChatLoading(true);

    try {
      // Find matching products locally for quick rich widget rendering
      const queryLower = text.toLowerCase();
      const localMatches = products.filter(
        p => p.title.toLowerCase().includes(queryLower) ||
             p.brand.toLowerCase().includes(queryLower) ||
             p.category.toLowerCase().includes(queryLower) ||
             p.tags.some(t => t.toLowerCase().includes(queryLower))
      ).slice(0, 3);

      const res = await fetch('/api/agent/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: chatMessages.slice(-6).map(m => ({ role: m.sender === 'user' ? 'user' : 'model', parts: [{ text: m.text }] })),
          currentCatalog: products.map(p => ({ id: p.id, title: p.title, price: p.currentPrice, score: p.dealScore })),
        }),
      });

      if (!res.ok) throw new Error('Agent service call failed');
      const data = await res.json();

      const agentMessage: AgentMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: data.text || "I found verified pricing and stock options for your request.",
        products: localMatches.length > 0 ? localMatches : undefined,
        suggestedActions: data.suggestedActions || [
          { type: 'search', label: 'Explore related items' },
          { type: 'coupon', label: 'Check retailer coupons' }
        ],
        toolInvocations: data.toolInvocations,
      };

      setChatMessages((prev) => [...prev, agentMessage]);
    } catch (err: any) {
      console.error('Agent chat error:', err);
      // Smart simulated fallback
      const agentMessage: AgentMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: `I analyzed your request: "${text}". Based on real-time price scans across 14 authorized retailers, I've identified the top matching products with the highest deal scores and active coupon codes.`,
        products: products.slice(0, 2),
        suggestedActions: [
          { type: 'compare', label: 'Compare top 2 models' },
          { type: 'coupon', label: 'Apply verified promo codes' },
        ],
        toolInvocations: [
          { tool: 'Retailer Catalog Indexer', status: 'completed', summary: 'Scanned 6 verified stores' },
          { tool: 'Coupon Validator', status: 'completed', summary: 'Found 3 active promo codes' }
        ]
      };

      setChatMessages((prev) => [...prev, agentMessage]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Search Submission
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    // Check if matching in local catalog
    const query = searchQuery.trim().toLowerCase();
    const localFiltered = products.filter(
      (p) =>
        p.title.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.tags.some((t) => t.toLowerCase().includes(query))
    );

    if (localFiltered.length > 0) {
      setCurrentView('catalog');
      return;
    }

    // Trigger Dynamic AI Search Grounding
    setIsSearchingLive(true);
    setCurrentView('catalog');

    try {
      const res = await fetch('/api/agent/search-products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery }),
      });

      if (!res.ok) throw new Error('Live search failed');
      const data = await res.json();

      if (data.products && data.products.length > 0) {
        setProducts((prev) => [...data.products, ...prev]);
        triggerToast('AI Real-Time Search', `Found ${data.products.length} live product matches for "${searchQuery}"`);
      } else {
        triggerToast('Search Complete', `Showing closest catalog matches for "${searchQuery}"`);
      }
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setIsSearchingLive(false);
    }
  };

  // Filtered Products for Catalog View
  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesStore = selectedStore === 'All' || product.stores.some(s => s.storeName === selectedStore);
    const matchesScore = product.dealScore >= minDealScore;
    const matchesQuery = !searchQuery.trim() || 
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesStore && matchesScore && matchesQuery;
  }).sort((a, b) => {
    if (sortBy === 'deal_score') return b.dealScore - a.dealScore;
    if (sortBy === 'price_low') return a.currentPrice - b.currentPrice;
    if (sortBy === 'price_high') return b.currentPrice - a.currentPrice;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-emerald-600 selection:text-white">
      
      {/* Toast Alert Notification */}
      {toastMessage && (
        <div 
          className={`fixed top-16 right-4 z-50 p-3 rounded-xl border shadow-xl backdrop-blur-md max-w-sm animate-in slide-in-from-top-3 duration-200 flex items-start gap-2.5 ${
            toastMessage.type === 'alert'
              ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-amber-900/10'
              : 'bg-white border-emerald-200 text-slate-800 shadow-emerald-900/10'
          }`}
        >
          <div className={`p-1 rounded-lg ${toastMessage.type === 'alert' ? 'bg-amber-200/60 text-amber-800' : 'bg-emerald-100 text-emerald-700'}`}>
            {toastMessage.type === 'alert' ? <Zap className="w-3.5 h-3.5 fill-current" /> : <Sparkles className="w-3.5 h-3.5" />}
          </div>
          <div className="space-y-0.5 flex-1">
            <h4 className="text-xs font-bold text-slate-900">{toastMessage.title}</h4>
            <p className="text-[11px] text-slate-600 leading-snug">{toastMessage.desc}</p>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-slate-700 text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Primary Navigation */}
      <Navbar
        currentView={currentView}
        onViewChange={setCurrentView}
        cartCount={cartCount}
        cartTotal={cartTotal}
        onOpenCart={() => setIsCartOpen(true)}
        compareCount={compareList.length}
        alertCount={priceAlerts.length}
        orderCount={orders.length}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        onOpenVisualSearch={() => setIsVisualSearchOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-5 lg:px-6 py-4 space-y-4">
        
        {/* 1. SHOPPING CATALOG VIEW */}
        {currentView === 'catalog' && (
          <div className="space-y-3.5">
            
            {/* Hero Banner with Agent Callout */}
            <div className="relative rounded-xl bg-slate-900 text-white border border-slate-800 p-4 sm:p-5 overflow-hidden shadow-xs">
              <div className="relative z-10 max-w-3xl space-y-2">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[11px] font-semibold border border-emerald-500/30">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Real-Time Retail Intelligence</span>
                </div>
                <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                  Stop Overpaying. AI Finds Verified Lowest Prices & Hidden Coupons.
                </h1>
                <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                  Aura continuously indexes live retailer inventories, verifies customer review authenticity, calculates price fairness scores, and tests promo codes automatically.
                </p>

                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={() => setCurrentView('agent')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-all"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    Open AI Shopper Chat
                  </button>
                  <button
                    onClick={() => setIsVisualSearchOpen(true)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 transition-all flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    Inspect Photo / URL Dupe
                  </button>
                </div>
              </div>
            </div>

            {/* Filter & Sort Bar */}
            <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2.5 shadow-xs">
              
              {/* Category Pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none">
                <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1 shrink-0">
                  <Filter className="w-3 h-3" /> Category:
                </span>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                      selectedCategory === cat
                        ? 'bg-slate-900 text-white shadow-xs font-semibold'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Secondary Filters */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
                
                {/* Store Filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 font-medium">Store:</span>
                  <select
                    value={selectedStore}
                    onChange={(e) => setSelectedStore(e.target.value)}
                    className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-800 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    {STORES.map((st) => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>

                {/* Min Deal Score Filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 font-medium">Min Score:</span>
                  <span className="font-bold text-emerald-700">{minDealScore}+</span>
                  <input
                    type="range"
                    min={0}
                    max={95}
                    step={5}
                    value={minDealScore}
                    onChange={(e) => setMinDealScore(Number(e.target.value))}
                    className="w-20 accent-emerald-600 bg-slate-200 h-1.5 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Sort Option */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 font-medium">Sort:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-800 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="deal_score">Highest AI Deal Score</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="rating">Top Customer Rated</option>
                  </select>
                </div>

                {/* Results count */}
                <span className="text-slate-500 font-medium ml-auto text-[11px]">
                  Showing <strong className="text-slate-800">{filteredProducts.length}</strong> items
                </span>

              </div>

            </div>

            {/* Live Search Loading Indicator */}
            {isSearchingLive && (
              <div className="p-4 bg-white border border-slate-200 rounded-xl text-center space-y-1 shadow-xs">
                <Loader2 className="w-5 h-5 text-emerald-600 animate-spin mx-auto" />
                <h4 className="text-xs font-bold text-slate-900">Aura Agent Grounded Search Active...</h4>
                <p className="text-[11px] text-slate-500">Scraping and analyzing verified real-time pricing for "{searchQuery}"</p>
              </div>
            )}

            {/* Product Cards Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-xl border border-slate-200 space-y-2 shadow-xs">
                <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">No Matching Products Found</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Try adjusting your filters or ask the AI Shopping Agent to search across more retailers.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('All');
                    setSelectedStore('All');
                    setMinDealScore(0);
                    setSearchQuery('');
                  }}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
                {filteredProducts.map((product) => {
                  const isComparing = compareList.some((p) => p.id === product.id);
                  const isAlertSet = priceAlerts.some((a) => a.productId === product.id);

                  return (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onSelectProduct={setSelectedProductDetail}
                      onAddToCart={handleAddToCart}
                      onToggleCompare={handleToggleCompare}
                      isComparing={isComparing}
                      onSetPriceAlert={handleSetPriceAlert}
                      isAlertSet={isAlertSet}
                      onAskAgentAboutProduct={(p) => {
                        setCurrentView('agent');
                        handleSendMessage(`What are the pros, cons, and current best retailer deals for ${p.title}?`);
                      }}
                    />
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* 2. AI SHOPPER CONVERSATIONAL CHAT */}
        {currentView === 'agent' && (
          <AgentChat
            messages={chatMessages}
            onSendMessage={handleSendMessage}
            isLoading={isChatLoading}
            onSelectProduct={setSelectedProductDetail}
            onAddToCart={handleAddToCart}
            onToggleCompare={handleToggleCompare}
            onSetPriceAlert={handleSetPriceAlert}
            onQuickPromptClick={handleSendMessage}
            onResetChat={() => {
              setChatMessages([
                {
                  id: 'msg-reset',
                  sender: 'agent',
                  timestamp: 'Just now',
                  text: "New shopping session initialized. What product or setup can I help you find and optimize?",
                }
              ]);
            }}
          />
        )}

        {/* 3. SIDE-BY-SIDE PRODUCT SHOWDOWN */}
        {currentView === 'compare' && (
          <PriceComparisonView
            compareList={compareList}
            onRemoveFromCompare={(id) => setCompareList(prev => prev.filter(p => p.id !== id))}
            onClearCompare={() => setCompareList([])}
            onSelectProduct={setSelectedProductDetail}
            onAddToCart={handleAddToCart}
            onOpenCatalog={() => setCurrentView('catalog')}
          />
        )}

        {/* 4. SETUPS & KIT BUILDER */}
        {currentView === 'kits' && (
          <KitBuilder
            onAddToCart={handleAddToCart}
            onAddMultipleToCart={handleAddMultipleToCart}
            onSelectProduct={setSelectedProductDetail}
          />
        )}

        {/* 5. PRICE WATCHDOG & ALERTS */}
        {currentView === 'alerts' && (
          <PriceWatchModal
            alerts={priceAlerts}
            onRemoveAlert={handleRemovePriceAlert}
            onUpdateTargetPrice={handleUpdateTargetPrice}
            onSimulatePriceDrop={handleSimulatePriceDrop}
            onSelectProductById={(id) => {
              const matched = products.find(p => p.id === id);
              if (matched) setSelectedProductDetail(matched);
            }}
            onOpenCatalog={() => setCurrentView('catalog')}
          />
        )}

        {/* 6. ORDERS & RECEIPTS */}
        {currentView === 'orders' && (
          <OrderHistoryModal
            orders={orders}
            onOpenCatalog={() => setCurrentView('catalog')}
          />
        )}

      </main>

      {/* MODALS */}

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProductDetail}
        onClose={() => setSelectedProductDetail(null)}
        onAddToCart={handleAddToCart}
        onToggleCompare={handleToggleCompare}
        isComparing={Boolean(selectedProductDetail && compareList.some(p => p.id === selectedProductDetail.id))}
        onSetPriceAlert={handleSetPriceAlert}
        isAlertSet={Boolean(selectedProductDetail && priceAlerts.some(a => a.productId === selectedProductDetail.id))}
        onAskAgentAboutProduct={(p) => {
          setSelectedProductDetail(null);
          setCurrentView('agent');
          handleSendMessage(`Can you do a deep-dive review and price comparison for ${p.title}?`);
        }}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onOpenCheckout={(discount) => {
          setAppliedCheckoutDiscount(discount);
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Autonomous Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cart}
        couponDiscount={appliedCheckoutDiscount}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* Visual & URL Search Modal */}
      <VisualSearchModal
        isOpen={isVisualSearchOpen}
        onClose={() => setIsVisualSearchOpen(false)}
        onSearchProductQuery={(query) => {
          setSearchQuery(query);
          setCurrentView('catalog');
        }}
        onAskAgentAboutItem={(query) => {
          setCurrentView('agent');
          handleSendMessage(query);
        }}
      />

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500 space-y-1.5">
        <div className="flex items-center justify-center gap-3 text-slate-600 font-medium">
          <span className="cursor-pointer hover:text-emerald-600" onClick={() => setCurrentView('catalog')}>Catalog</span>
          <span>•</span>
          <span className="cursor-pointer hover:text-emerald-600" onClick={() => setCurrentView('agent')}>AI Shopper</span>
          <span>•</span>
          <span className="cursor-pointer hover:text-emerald-600" onClick={() => setCurrentView('compare')}>Compare</span>
          <span>•</span>
          <span className="cursor-pointer hover:text-emerald-600" onClick={() => setCurrentView('kits')}>Setup Kits</span>
          <span>•</span>
          <span className="cursor-pointer hover:text-emerald-600" onClick={() => setCurrentView('alerts')}>Price Watch</span>
        </div>
        <p>© 2026 Aura AI Shopping Agent. Powered by Google Gemini 3.7 & Real-Time Retailer Grounding.</p>
      </footer>

    </div>
  );
}
