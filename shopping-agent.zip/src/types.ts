export interface StorePrice {
  storeName: 'Amazon' | 'Best Buy' | 'Walmart' | 'Target' | 'B&H Photo' | 'Nike' | 'eBay' | 'Newegg' | 'Apple' | 'Direct Store';
  storeLogo?: string;
  price: number;
  originalPrice?: number;
  inStock: boolean;
  shipping: string; // e.g. "Free 2-day delivery", "$4.99 standard"
  url: string;
  condition: 'New' | 'Refurbished (Excellent)' | 'Open Box';
  rating: number;
  isLowest?: boolean;
}

export interface PricePoint {
  date: string; // "Jan", "Feb", etc. or "2026-07-01"
  price: number;
}

export interface Coupon {
  code: string;
  discountDescription: string;
  discountAmount?: number; // e.g. 15 for 15% or $20
  discountType: 'percentage' | 'fixed';
  store: string;
  successRate: number; // e.g. 92%
  verifiedDate: string;
  expiration?: string;
}

export interface Product {
  id: string;
  title: string;
  brand: string;
  category: 'Electronics' | 'Home & Living' | 'Fashion & Apparel' | 'Audio & Wearables' | 'Kitchen' | 'Fitness & Outdoors' | 'Gaming';
  rating: number;
  reviewCount: number;
  imageUrl: string;
  currentPrice: number;
  originalPrice: number;
  dealScore: number; // 0 to 100
  dealLabel?: string; // "Lowest in 90 days", "28% OFF", "Prime Deal Match"
  stores: StorePrice[];
  description: string;
  specs: Record<string, string>;
  pros: string[];
  cons: string[];
  aiVerdict: string;
  priceHistory: PricePoint[];
  coupons: Coupon[];
  tags: string[];
  isStaffPick?: boolean;
  fakeReviewRisk?: 'Low (Verified)' | 'Moderate' | 'High';
  targetPriceAlert?: number;
}

export interface CartItem {
  product: Product;
  selectedStore: StorePrice;
  quantity: number;
  appliedCoupon?: Coupon;
}

export interface PriceAlert {
  id: string;
  productId: string;
  productTitle: string;
  productImage: string;
  targetPrice: number;
  currentPrice: number;
  originalPrice: number;
  createdAt: string;
  active: boolean;
  notified?: boolean;
}

export interface Order {
  id: string;
  date: string;
  items: {
    productTitle: string;
    productImage: string;
    storeName: string;
    price: number;
    quantity: number;
  }[];
  totalSavings: number;
  totalAmount: number;
  shippingAddress: string;
  status: 'Processing' | 'Confirmed' | 'Shipped' | 'Delivered';
  agentNotes: string;
  trackingNumber: string;
}

export interface ShoppingKitItem {
  categoryName: string;
  selectedProduct: Product;
  alternativeProducts?: Product[];
}

export interface ShoppingKit {
  id: string;
  title: string;
  description: string;
  targetBudget: number;
  totalPrice: number;
  items: ShoppingKitItem[];
  savingsTotal: number;
}

export interface AgentAction {
  type: 'search' | 'compare' | 'coupon' | 'add_to_cart' | 'price_alert' | 'build_kit';
  label: string;
  payload?: any;
}

export interface AgentMessage {
  id: string;
  sender: 'user' | 'agent';
  timestamp: string;
  text: string;
  products?: Product[];
  suggestedActions?: AgentAction[];
  isThinking?: boolean;
  toolInvocations?: {
    tool: string;
    status: 'running' | 'completed' | 'failed';
    summary: string;
  }[];
  comparisonData?: {
    items: Product[];
    winnerId: string;
    rationale: string;
    metricComparison: {
      feature: string;
      values: Record<string, string>;
      winnerStoreOrProduct?: string;
    }[];
  };
  kitData?: ShoppingKit;
}

export type ViewMode = 'catalog' | 'agent' | 'compare' | 'kits' | 'alerts' | 'orders';
